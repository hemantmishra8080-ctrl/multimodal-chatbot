@echo off
title Multimodal AI Companion
echo ===================================================
echo   Starting Multimodal AI Companion
echo   FastAPI Backend (8000) + Streamlit Frontend (8501)
echo ===================================================

where python >nul 2>nul
if %errorlevel% equ 0 (
    python app.py run
) else (
    if exist C:\Python315\python.exe (
        C:\Python315\python.exe app.py run
    ) else (
        echo Error: Python was not found in PATH or at C:\Python315\python.exe.
        pause
    )
)
pause


"""Repository for Document and DocumentChunk database operations."""
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from backend.db.models import Document, DocumentChunk


class DocumentRepository:
    """Manages document metadata and relational chunk indices."""

    @staticmethod
    def create(
        db: Session,
        filename: str,
        content_hash: str,
        mime_type: str,
        size_bytes: int,
        status: str = "indexed",
    ) -> Document:
        doc = Document(
            filename=filename,
            content_hash=content_hash,
            mime_type=mime_type,
            size_bytes=size_bytes,
            status=status,
        )
        db.add(doc)
        db.flush()
        return doc

    @staticmethod
    def get_by_hash(db: Session, content_hash: str) -> Optional[Document]:
        stmt = select(Document).where(Document.content_hash == content_hash)
        return db.scalar(stmt)

    @staticmethod
    def get_by_id(db: Session, document_id: str) -> Optional[Document]:
        stmt = select(Document).where(Document.id == document_id)
        return db.scalar(stmt)

    @staticmethod
    def list_all(db: Session) -> List[Document]:
        stmt = select(Document).order_by(desc(Document.created_at))
        return list(db.scalars(stmt).all())

    @staticmethod
    def delete(db: Session, document_id: str) -> Optional[Document]:
        doc = DocumentRepository.get_by_id(db, document_id)
        if not doc:
            return None
        db.delete(doc)
        db.flush()
        return doc

    @staticmethod
    def add_chunks(
        db: Session,
        document_id: str,
        chunks_data: List[Dict[str, Any]],
    ) -> List[DocumentChunk]:
        created_chunks = []
        for c in chunks_data:
            chunk = DocumentChunk(
                document_id=document_id,
                chunk_index=c["chunk_index"],
                page_number=c.get("page_number"),
                vector_id=c["vector_id"],
                text_preview=c.get("text_preview"),
            )
            db.add(chunk)
            created_chunks.append(chunk)
        db.flush()
        return created_chunks

    @staticmethod
    def get_chunks_for_document(db: Session, document_id: str) -> List[DocumentChunk]:
        stmt = (
            select(DocumentChunk)
            .where(DocumentChunk.document_id == document_id)
            .order_by(DocumentChunk.chunk_index.asc())
        )
        return list(db.scalars(stmt).all())

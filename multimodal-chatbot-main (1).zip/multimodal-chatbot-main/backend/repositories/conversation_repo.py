"""Repository for Conversation and Message database operations."""
from typing import List, Optional
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from backend.db.models import Conversation, Message


class ConversationRepository:
    """Manages conversations and message history in relational storage."""

    @staticmethod
    def create(db: Session, title: str = "New Conversation") -> Conversation:
        conv = Conversation(title=title)
        db.add(conv)
        db.flush()
        return conv

    @staticmethod
    def get_by_id(db: Session, conversation_id: str) -> Optional[Conversation]:
        stmt = select(Conversation).where(Conversation.id == conversation_id)
        return db.scalar(stmt)

    @staticmethod
    def list_all(db: Session, limit: int = 50, offset: int = 0) -> List[Conversation]:
        stmt = (
            select(Conversation)
            .order_by(desc(Conversation.updated_at))
            .limit(limit)
            .offset(offset)
        )
        return list(db.scalars(stmt).all())

    @staticmethod
    def delete(db: Session, conversation_id: str) -> bool:
        conv = ConversationRepository.get_by_id(db, conversation_id)
        if not conv:
            return False
        db.delete(conv)
        db.flush()
        return True

    @staticmethod
    def add_message(
        db: Session,
        conversation_id: str,
        role: str,
        content: str,
        modality: str = "text",
        metadata_json: Optional[dict] = None,
    ) -> Message:
        msg = Message(
            conversation_id=conversation_id,
            role=role,
            content=content,
            modality=modality,
            metadata_json=metadata_json,
        )
        db.add(msg)
        
        # Update conversation's updated_at timestamp
        conv = ConversationRepository.get_by_id(db, conversation_id)
        if conv:
            conv.updated_at = datetime.now(timezone.utc)
            db.add(conv)

        db.flush()
        return msg

    @staticmethod
    def get_messages(db: Session, conversation_id: str, limit: int = 100) -> List[Message]:
        stmt = (
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(Message.created_at.desc())
            .limit(limit)
        )
        msgs = list(db.scalars(stmt).all())
        msgs.reverse()  # Return in chronological order (oldest to newest)
        return msgs

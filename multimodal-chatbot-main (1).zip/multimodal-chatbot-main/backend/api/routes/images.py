"""Image generation and image file serving endpoints."""
import os
from pathlib import Path
from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse
from backend.core.config import settings
from backend.services.image_generation_service import ImageGenerationService


router = APIRouter(prefix="/api/v1/image", tags=["Image Generation"])


class ImageGenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=2, max_length=1000, description="Text prompt describing the desired image")
    provider: Optional[str] = Field("auto", description="Provider: auto, openai, flux")
    api_key: Optional[str] = Field(None, description="Optional OpenAI key for DALL-E")


class ImageGenerateResponse(BaseModel):
    status: str
    prompt: str
    image_url: str
    image_base64: Optional[str] = None
    provider: str


@router.post("/generate", response_model=ImageGenerateResponse, status_code=status.HTTP_200_OK)
async def generate_image_endpoint(req: ImageGenerateRequest):
    """Generate an image from a natural language prompt."""
    result = await ImageGenerationService.generate_image(
        prompt=req.prompt,
        provider=req.provider or "auto",
        api_key=req.api_key,
    )
    if result.get("status") != "success":
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate image.",
        )
    return ImageGenerateResponse(
        status="success",
        prompt=result["prompt"],
        image_url=result["image_url"],
        image_base64=result.get("image_base64"),
        provider=result.get("provider", "flux-diffusion"),
    )


@router.get("/{filename}")
async def get_cached_image(filename: str):
    """Serve a locally cached generated image."""
    safe_name = os.path.basename(filename)
    path = Path(settings.GENERATED_IMAGES_DIR) / safe_name
    if not path.is_file():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Image not found")
    return FileResponse(path, media_type="image/jpeg")


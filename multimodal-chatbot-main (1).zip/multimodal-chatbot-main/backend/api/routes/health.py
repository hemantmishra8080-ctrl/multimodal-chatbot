"""Health check endpoint."""
from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session
from backend.core.config import settings
from backend.api.deps import get_database
from backend.schemas.common import HealthResponse


router = APIRouter(tags=["Health"])


@router.get("/health", response_model=HealthResponse)
def get_health(db: Session = Depends(get_database)):
    """
    Application health status check.
    Confirms database connectivity, vector store readiness, and configured provider mode
    without disclosing internal credentials, full paths, or sensitive architecture info.
    """
    db_status = "connected"
    try:
        db.execute(text("SELECT 1"))
    except Exception:
        db_status = "unavailable"

    return HealthResponse(
        status="healthy" if db_status == "connected" else "degraded",
        app_name=settings.APP_NAME,
        version="1.0.0",
        database=db_status,
        vector_store="ready",
        llm_provider=settings.LLM_PROVIDER,
    )

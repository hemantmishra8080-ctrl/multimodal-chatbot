"""Chat endpoint handling conversational messages, RAG, and multimodal inputs."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.api.deps import get_database
from backend.schemas.chat import ChatRequest, ChatResponse
from backend.services.chat_service import ChatService


router = APIRouter(prefix="/api/v1/chat", tags=["Chat"])


@router.post("", response_model=ChatResponse, status_code=status.HTTP_200_OK)
async def post_chat(
    request: ChatRequest,
    db: Session = Depends(get_database),
):
    """
    Submit a conversational message, document query, or multimodal prompt.
    Returns assistant response with optional source citations.
    """
    try:
        return await ChatService.process_chat(db, request)
    except ValueError as val_err:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(val_err))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while generating the response.",
        )

"""Audio endpoints for speech synthesis and transcription."""
import base64
from fastapi import APIRouter, UploadFile, File, HTTPException, status
from backend.schemas.audio import (
    AudioSynthesizeRequest,
    AudioSynthesizeResponse,
    AudioTranscriptionResponse,
)
from backend.services.multimodal_service import MultimodalService
from backend.providers.audio_provider import get_audio_provider


router = APIRouter(prefix="/api/v1/audio", tags=["Audio"])


@router.post("/synthesize", response_model=AudioSynthesizeResponse)
def synthesize_speech(request: AudioSynthesizeRequest):
    """
    Synthesize text into spoken WAV audio (base64 encoded).
    Uses local pyttsx3 engine (zero API cost).
    """
    try:
        audio_bytes = MultimodalService.synthesize_speech(
            text=request.text,
            voice_speed=request.voice_speed or 175,
        )
        b64_audio = base64.b64encode(audio_bytes).decode("utf-8")
        return AudioSynthesizeResponse(
            audio_base64=b64_audio,
            format="wav",
            sample_rate=22050,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Speech synthesis failed: {exc}",
        )


@router.post("/transcribe", response_model=AudioTranscriptionResponse)
async def transcribe_speech(file: UploadFile = File(...)):
    """
    Transcribe speech audio into text.
    """
    try:
        content = await file.read()
        audio_provider = get_audio_provider()
        transcript = await audio_provider.transcribe_audio(content, mime_type=file.content_type or "audio/wav")
        return AudioTranscriptionResponse(transcript=transcript, confidence=1.0)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Audio transcription failed: {exc}",
        )

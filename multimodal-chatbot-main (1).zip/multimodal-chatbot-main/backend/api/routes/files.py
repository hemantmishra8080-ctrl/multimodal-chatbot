"""Files router for downloading generated scripts, datasets, and reports."""
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse
from backend.services.file_generation_service import FileGenerationService, MIME_MAP

router = APIRouter(prefix="/api/v1/files", tags=["Files"])


@router.get("/download/{file_id}")
async def download_file(file_id: str):
    """Download a generated file by its unique identifier."""
    found = FileGenerationService.get_file_by_id(file_id)
    if not found:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"File with ID '{file_id}' not found or has expired.",
        )

    file_path, original_filename = found
    ext = original_filename.rsplit(".", 1)[-1].lower() if "." in original_filename else "txt"
    media_type = MIME_MAP.get(ext, "application/octet-stream")

    return FileResponse(
        path=str(file_path),
        filename=original_filename,
        media_type=media_type,
    )

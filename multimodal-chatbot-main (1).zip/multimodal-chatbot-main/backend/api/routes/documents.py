"""Document management endpoints: upload, ingestion, listing, and deletion."""
from typing import List
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, status
from sqlalchemy.orm import Session
from backend.api.deps import get_database
from backend.schemas.document import (
    DocumentMetadataResponse,
    DocumentListResponse,
    DocumentDeleteResponse,
)
from backend.services.document_service import DocumentService
from backend.repositories.document_repo import DocumentRepository


router = APIRouter(prefix="/api/v1/documents", tags=["Documents"])


@router.post("", response_model=DocumentMetadataResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_database),
):
    """
    Upload and index a PDF or TXT document for RAG retrieval.
    Applies SHA-256 deduplication, magic-byte inspection, and vector indexing.
    """
    content = await file.read()
    filename = file.filename or "uploaded_document"
    mime_type = file.content_type or "application/octet-stream"

    # Infer MIME type if default octet-stream provided
    if mime_type == "application/octet-stream":
        if filename.lower().endswith(".pdf"):
            mime_type = "application/pdf"
        elif filename.lower().endswith(".txt"):
            mime_type = "text/plain"

    try:
        doc, is_existing = DocumentService.ingest_document(
            db=db,
            content=content,
            filename=filename,
            mime_type=mime_type,
        )
        return DocumentMetadataResponse(
            id=doc.id,
            filename=doc.filename,
            content_hash=doc.content_hash,
            mime_type=doc.mime_type,
            size_bytes=doc.size_bytes,
            status=doc.status,
            created_at=doc.created_at,
            chunk_count=len(doc.chunks) if doc.chunks else 0,
        )
    except ValueError as val_err:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(val_err))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Document processing failed: {exc}",
        )


@router.get("", response_model=DocumentListResponse)
def list_documents(db: Session = Depends(get_database)):
    """List all ingested document metadata and chunk counts."""
    docs = DocumentRepository.list_all(db)
    items = []
    for d in docs:
        items.append(
            DocumentMetadataResponse(
                id=d.id,
                filename=d.filename,
                content_hash=d.content_hash,
                mime_type=d.mime_type,
                size_bytes=d.size_bytes,
                status=d.status,
                created_at=d.created_at,
                chunk_count=len(d.chunks),
            )
        )
    return DocumentListResponse(documents=items, total=len(items))


@router.delete("/{document_id}", response_model=DocumentDeleteResponse)
def delete_document(
    document_id: str,
    db: Session = Depends(get_database),
):
    """
    Delete a document, its database chunks, and associated vector index entries.
    """
    success, deleted_vectors, filename = DocumentService.delete_document(db, document_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{document_id}' not found.",
        )

    return DocumentDeleteResponse(
        document_id=document_id,
        filename=filename,
        deleted_chunks=deleted_vectors,
        success=True,
        message=f"Document '{filename}' and {deleted_vectors} vector entries successfully deleted.",
    )

"""Conversations management endpoints."""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.api.deps import get_database
from backend.schemas.conversation import (
    ConversationCreate,
    ConversationResponse,
    ConversationDetailResponse,
    MessageResponse,
)
from backend.schemas.common import StatusResponse
from backend.repositories.conversation_repo import ConversationRepository


router = APIRouter(prefix="/api/v1/conversations", tags=["Conversations"])


@router.get("", response_model=List[ConversationResponse])
def list_conversations(
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_database),
):
    """List locally stored conversation threads."""
    convs = ConversationRepository.list_all(db, limit=limit, offset=offset)
    result = []
    for c in convs:
        result.append(
            ConversationResponse(
                id=c.id,
                title=c.title,
                created_at=c.created_at,
                updated_at=c.updated_at,
                message_count=len(c.messages),
            )
        )
    return result


@router.post("", response_model=ConversationResponse, status_code=status.HTTP_201_CREATED)
def create_conversation(
    req: ConversationCreate,
    db: Session = Depends(get_database),
):
    """Create a new conversation thread."""
    conv = ConversationRepository.create(db, title=req.title or "New Conversation")
    return ConversationResponse(
        id=conv.id,
        title=conv.title,
        created_at=conv.created_at,
        updated_at=conv.updated_at,
        message_count=0,
    )


@router.get("/{conversation_id}", response_model=ConversationDetailResponse)
def get_conversation(
    conversation_id: str,
    db: Session = Depends(get_database),
):
    """Retrieve all messages for a specific conversation."""
    conv = ConversationRepository.get_by_id(db, conversation_id)
    if not conv:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation '{conversation_id}' not found.",
        )

    messages = [
        MessageResponse(
            id=m.id,
            conversation_id=m.conversation_id,
            role=m.role,
            content=m.content,
            modality=m.modality,
            metadata_json=m.metadata_json,
            created_at=m.created_at,
        )
        for m in conv.messages
    ]

    return ConversationDetailResponse(
        id=conv.id,
        title=conv.title,
        created_at=conv.created_at,
        updated_at=conv.updated_at,
        messages=messages,
    )


@router.delete("/{conversation_id}", response_model=StatusResponse)
def delete_conversation(
    conversation_id: str,
    db: Session = Depends(get_database),
):
    """Delete a conversation thread and its associated message history."""
    deleted = ConversationRepository.delete(db, conversation_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation '{conversation_id}' not found.",
        )
    return StatusResponse(
        success=True,
        message=f"Conversation '{conversation_id}' and associated messages deleted.",
    )

"""RAG query endpoint for grounded document question-answering."""
from fastapi import APIRouter, HTTPException, status
from backend.schemas.rag import RAGQueryRequest, RAGQueryResponse
from backend.services.rag_service import RAGService


router = APIRouter(prefix="/api/v1/rag", tags=["RAG"])


@router.post("/query", response_model=RAGQueryResponse)
async def query_rag_documents(request: RAGQueryRequest):
    """
    Ask a question over the indexed document knowledge base.
    Returns context-grounded answer accompanied by verifiable source citations.
    """
    try:
        return await RAGService.answer_query(
            query=request.query,
            document_id=request.document_id,
            top_k=request.top_k or 3,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"RAG query execution failed: {exc}",
        )

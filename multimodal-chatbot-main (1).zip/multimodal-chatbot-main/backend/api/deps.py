"""API dependency injection."""
from typing import Generator
from fastapi import Depends
from sqlalchemy.orm import Session
from backend.db.session import get_db


def get_database() -> Generator[Session, None, None]:
    """Dependency that provides a transactional SQLAlchemy session."""
    yield from get_db()

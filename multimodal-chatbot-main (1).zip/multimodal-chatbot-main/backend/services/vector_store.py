"""Vector store abstraction with persistent pure-Python/NumPy engine and ChromaDB compatibility."""
import json
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import numpy as np
from backend.core.config import settings
from backend.core.logging_config import logger


class VectorStoreBase(ABC):
    """Abstract interface for storing and searching vector embeddings."""

    @abstractmethod
    def add_records(self, records: List[Dict[str, Any]]) -> List[str]:
        """
        Add items with vectors and metadata.
        Each record has: id, vector (List[float]), text, metadata (dict: document_id, filename, page, chunk_index)
        """
        pass

    @abstractmethod
    def search(
        self,
        query_vector: List[float],
        top_k: int = 3,
        filter_document_id: Optional[str] = None,
        threshold: float = 0.0,
    ) -> List[Dict[str, Any]]:
        """Return top_k matching records sorted by cosine similarity."""
        pass

    @abstractmethod
    def delete_by_document_id(self, document_id: str) -> int:
        """Remove all vectors corresponding to a document ID."""
        pass


class LocalVectorStore(VectorStoreBase):
    """
    Persistent, pure-Python / NumPy vector store.
    Stores dense vectors and metadata in JSON / NumPy format on disk.
    Guarantees 100% compatibility across all Python versions without native binary compilation.
    """

    def __init__(self, storage_dir: Optional[str] = None):
        self.storage_dir = Path(storage_dir or settings.VECTOR_STORE_PATH)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.index_file = self.storage_dir / "index.json"
        self.records: List[Dict[str, Any]] = []
        self._load_index()

    def _load_index(self) -> None:
        if self.index_file.exists():
            try:
                with open(self.index_file, "r", encoding="utf-8") as f:
                    self.records = json.load(f)
                logger.info(f"Loaded {len(self.records)} vector records from {self.index_file}")
            except Exception as exc:
                logger.error(f"Failed to load vector index ({exc}). Initializing fresh index.")
                self.records = []
        else:
            self.records = []

    def _save_index(self) -> None:
        try:
            with open(self.index_file, "w", encoding="utf-8") as f:
                json.dump(self.records, f, ensure_ascii=False, indent=2)
        except Exception as exc:
            logger.error(f"Failed to save vector index to disk: {exc}")

    def add_records(self, records: List[Dict[str, Any]]) -> List[str]:
        ids = []
        for r in records:
            self.records.append(r)
            ids.append(r["id"])
        self._save_index()
        return ids

    def search(
        self,
        query_vector: List[float],
        top_k: int = 3,
        filter_document_id: Optional[str] = None,
        threshold: float = 0.0,
    ) -> List[Dict[str, Any]]:
        if not self.records or not query_vector:
            return []

        q_vec = np.array(query_vector, dtype=np.float32)
        q_norm = np.linalg.norm(q_vec)
        if q_norm == 0:
            return []

        scored_records = []
        for r in self.records:
            # Document filter check
            doc_id = r.get("metadata", {}).get("document_id")
            if filter_document_id and doc_id != filter_document_id:
                continue

            r_vec = np.array(r["vector"], dtype=np.float32)
            r_norm = np.linalg.norm(r_vec)
            if r_norm == 0:
                continue

            # Cosine similarity
            cos_sim = float(np.dot(q_vec, r_vec) / (q_norm * r_norm))
            if cos_sim >= threshold:
                scored_records.append({
                    "id": r["id"],
                    "text": r["text"],
                    "metadata": r.get("metadata", {}),
                    "score": cos_sim,
                })

        # Sort descending by similarity score
        scored_records.sort(key=lambda x: x["score"], reverse=True)
        return scored_records[:top_k]

    def delete_by_document_id(self, document_id: str) -> int:
        initial_count = len(self.records)
        self.records = [
            r for r in self.records
            if r.get("metadata", {}).get("document_id") != document_id
        ]
        deleted = initial_count - len(self.records)
        if deleted > 0:
            self._save_index()
            logger.info(f"Deleted {deleted} vectors for document_id={document_id}")
        return deleted


_vector_store_instance = LocalVectorStore()


def get_vector_store() -> VectorStoreBase:
    """Return the active singleton vector store instance."""
    return _vector_store_instance

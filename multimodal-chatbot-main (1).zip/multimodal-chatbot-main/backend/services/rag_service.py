"""RAG retrieval, prompt grounding, and citation generation service."""
from typing import Optional, List, Dict, Any
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.schemas.chat import CitationItem
from backend.schemas.rag import RAGQueryResponse
from backend.services.vector_store import get_vector_store
from backend.providers.embedding_provider import get_embedding_provider
from backend.providers import get_llm_provider
from backend.guardrails.prompt_injection import PromptInjectionGuardrail
from backend.guardrails.output_validation import OutputGuardrail


class RAGService:
    """Manages context retrieval, prompt grounding, and citation formatting."""

    @classmethod
    async def answer_query(
        cls,
        query: str,
        document_id: Optional[str] = None,
        top_k: int = settings.RETRIEVAL_TOP_K,
    ) -> RAGQueryResponse:
        vector_store = get_vector_store()
        embedding_provider = get_embedding_provider()
        llm_provider = get_llm_provider()

        # 1. Embed query
        query_vector = embedding_provider.embed_query(query)

        # 2. Similarity search
        matches = vector_store.search(
            query_vector=query_vector,
            top_k=top_k,
            filter_document_id=document_id,
            threshold=settings.RETRIEVAL_SIMILARITY_THRESHOLD,
        )

        # 3. Handle insufficient context
        if not matches:
            return RAGQueryResponse(
                query=query,
                answer=(
                    "I searched the available documents, but could not find sufficient relevant information "
                    "to answer your question reliably. Please try rephrasing your question or ensure the relevant "
                    "document has been uploaded and indexed."
                ),
                citations=[],
                has_sufficient_context=False,
            )

        # 4. Format citation objects
        citations: List[CitationItem] = []
        context_chunks: List[Dict[str, Any]] = []

        for m in matches:
            meta = m.get("metadata", {})
            citation = CitationItem(
                document_id=meta.get("document_id", ""),
                filename=meta.get("filename", "unknown"),
                page_number=meta.get("page_number"),
                chunk_index=meta.get("chunk_index", 0),
                text_snippet=m.get("text", "")[:250],
                score=round(m.get("score", 0.0), 3),
            )
            citations.append(citation)
            context_chunks.append({
                "filename": meta.get("filename", "unknown"),
                "page_number": meta.get("page_number", "N/A"),
                "text": m.get("text", ""),
            })

        # 5. Build strict context-grounded prompt
        grounded_context = PromptInjectionGuardrail.build_grounded_context_prompt(context_chunks)
        system_instruction = (
            "You are a helpful and precise document-grounded AI companion. "
            "Your task is to answer the user's question using ONLY the provided reference documents. "
            "Do not invent facts or cite documents that do not exist. "
            "If the document does not contain enough information to give a complete answer, state so honestly.\n\n"
            f"{grounded_context}"
        )

        messages = [{"role": "user", "content": query}]

        # 6. Generate answer
        raw_answer = await llm_provider.generate_response(
            messages=messages,
            system_prompt=system_instruction,
            temperature=0.3,  # Low temperature for factual precision
        )

        # 7. Output sanitization
        clean_answer = OutputGuardrail.sanitize_response(raw_answer)

        return RAGQueryResponse(
            query=query,
            answer=clean_answer,
            citations=citations,
            has_sufficient_context=True,
        )

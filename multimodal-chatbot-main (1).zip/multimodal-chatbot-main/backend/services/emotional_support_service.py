"""Emotional Support Companion Service with empathy prompts and safety boundaries."""
from typing import List, Dict, Optional, Tuple
from backend.guardrails.safety import SafetyGuardrail


class EmotionalSupportService:
    """Orchestrates empathetic dialogue, grounding techniques, and ethical boundaries."""

    EMPATHETIC_SYSTEM_PROMPT = (
        "You are an empathetic, compassionate, and gentle AI Companion. "
        "Your mission is to provide non-judgmental emotional support, attentive listening, "
        "and constructive encouragement to help users process thoughts and feelings.\n\n"
        "Guidelines:\n"
        "1. Validate the user's emotional experience without making sweeping assumptions.\n"
        "2. Communicate with warmth, patience, and kindness.\n"
        "3. Offer practical, healthy coping tools when helpful: box breathing, the 5-4-3-2-1 sensory "
        "grounding technique, mindful self-compassion, and reflective journaling.\n"
        "4. Encourage the user's personal autonomy and connections with real-world trusted friends and community.\n\n"
        "Ethical Boundaries:\n"
        "- You are an AI companion, NOT a human, doctor, psychologist, or medical professional.\n"
        "- Never provide medical or clinical psychiatric diagnoses.\n"
        "- Never advise discontinuing or modifying prescribed medications.\n"
        "- Never encourage emotional exclusivity, secrecy, or isolation from friends and family."
    )

    @classmethod
    def check_safety_and_intercept(cls, user_message: str) -> Tuple[bool, Optional[str]]:
        """
        Check if message requires deterministic crisis intervention or medical boundary.
        Returns (intercepted, response_text).
        """
        # 1. Immediate Crisis / Self-Harm Interception
        if SafetyGuardrail.detect_crisis(user_message):
            return True, SafetyGuardrail.get_crisis_response()

        return False, None

    @classmethod
    def format_support_prompt(cls, user_message: str) -> str:
        """Append ethical disclaimer if medical or medication advice was touched upon."""
        prompt = cls.EMPATHETIC_SYSTEM_PROMPT
        if SafetyGuardrail.check_medical_disclaimer_needed(user_message):
            prompt += SafetyGuardrail.get_medical_disclaimer()
        return prompt

"""AI Image Generation Service using Free Fast Neural Diffusion (Pollinations.ai)."""
import re
import uuid
import base64
import urllib.parse
from typing import Tuple, Dict, Any, Optional
from pathlib import Path
import httpx
from backend.core.config import settings
from backend.core.logging_config import logger


class ImageGenerationService:
    """Manages AI image generation, prompt parsing, caching, and local storage."""

    IMAGE_TRIGGER_PATTERNS = [
        r"(?:can you\s+)?(?:please\s+)?(?:generate|create|make|draw|paint|render)\s+(?:an?\s+|the\s+)?(?:image|picture|photo|illustration|drawing|artwork|portrait)\s+of\s+(.+)",
        r"(?:can you\s+)?(?:please\s+)?(?:draw|paint|sketch)\s+(?:me\s+)?(?:an?\s+|the\s+)?(.+)",
        r"image\s+of\s+(.+)",
        r"picture\s+of\s+(.+)",
    ]

    @classmethod
    def detect_image_request(cls, text: str) -> Tuple[bool, str]:
        """
        Check if the user message is requesting image generation,
        and extract the clean image subject description.
        """
        cleaned = text.strip()
        for pattern in cls.IMAGE_TRIGGER_PATTERNS:
            match = re.search(pattern, cleaned, re.IGNORECASE)
            if match:
                extracted = match.group(1).strip().rstrip(".?!")
                if len(extracted) > 1 and not extracted.lower().startswith("what"):
                    return True, extracted
        return False, ""

    @classmethod
    async def generate_image(
        cls,
        prompt: str,
        provider: str = "auto",
        api_key: Optional[str] = None,
        width: int = 1024,
        height: int = 1024,
    ) -> Dict[str, Any]:
        """
        Generate an image from a text description.
        Uses free, high-speed neural diffusion by default, or OpenAI DALL-E if key provided.
        """
        clean_prompt = prompt.strip()
        settings.ensure_directories()
        img_id = str(uuid.uuid4())
        file_path = Path(settings.GENERATED_IMAGES_DIR) / f"{img_id}.jpg"
        encoded_prompt = urllib.parse.quote(clean_prompt)

        # 1. DALL-E via OpenAI if key is provided
        openai_key = api_key if (api_key and provider in ("openai", "auto")) else None
        if not openai_key:
            openai_key = getattr(settings, "OPENAI_API_KEY", None) or None

        if openai_key and provider == "openai":
            try:
                logger.info(f"Generating image via OpenAI DALL-E for: {clean_prompt[:50]}")
                async with httpx.AsyncClient(timeout=60.0) as client:
                    resp = await client.post(
                        "https://api.openai.com/v1/images/generations",
                        headers={"Authorization": f"Bearer {openai_key}"},
                        json={
                            "model": "dall-e-3",
                            "prompt": clean_prompt,
                            "n": 1,
                            "size": "1024x1024",
                            "response_format": "b64_json",
                        },
                    )
                    if resp.status_code == 200:
                        b64_data = resp.json()["data"][0]["b64_json"]
                        img_bytes = base64.b64decode(b64_data)
                        file_path.write_bytes(img_bytes)
                        return {
                            "status": "success",
                            "prompt": clean_prompt,
                            "image_base64": b64_data,
                            "image_url": f"/api/v1/image/{img_id}.jpg",
                            "file_path": str(file_path),
                            "provider": "openai-dalle-3",
                        }
            except Exception as exc:
                logger.warning(f"OpenAI image generation failed: {exc}")

        # 2. Fast Free Neural Diffusion (Pollinations.ai)
        # Primary working URL without problematic query params
        poll_url = f"https://image.pollinations.ai/prompt/{encoded_prompt}?nologo=true"

        try:
            logger.info(f"Generating image via Pollinations for: {clean_prompt[:50]}")
            async with httpx.AsyncClient(timeout=25.0, follow_redirects=True) as client:
                res = await client.get(poll_url)
                if res.status_code == 200 and len(res.content) > 1000:
                    file_path.write_bytes(res.content)
                    b64_data = base64.b64encode(res.content).decode("utf-8")
                    logger.info(f"Image generated and downloaded successfully ({len(res.content)//1024} KB)")
                    return {
                        "status": "success",
                        "prompt": clean_prompt,
                        "image_base64": b64_data,
                        "image_url": poll_url,
                        "file_path": str(file_path),
                        "provider": "flux-diffusion",
                    }
        except Exception as exc:
            logger.warning(f"Image download had exception: {exc}")

        # Direct link fallback for browser rendering
        return {
            "status": "success",
            "prompt": clean_prompt,
            "image_base64": None,
            "image_url": poll_url,
            "file_path": None,
            "provider": "flux-diffusion",
        }

"""Multimodal service: image processing, vision understanding, and audio dispatch."""
import io
import base64
from typing import Optional, Tuple
from PIL import Image
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.core.security import validate_file_signature
from backend.providers.vision_provider import get_vision_provider
from backend.providers.audio_provider import get_audio_provider


class MultimodalService:
    """Coordinates image understanding and audio synthesis."""

    @staticmethod
    def validate_and_decode_image(b64_str: str) -> Tuple[bytes, str]:
        """
        Validate base64 image string, verify byte header, and check dimensions.
        Returns (image_bytes, mime_type).
        """
        try:
            # Strip data URI header if present
            if "," in b64_str:
                header, data = b64_str.split(",", 1)
                b64_str = data

            image_bytes = base64.b64decode(b64_str)
        except Exception as exc:
            raise ValueError(f"Invalid base64 image encoding: {exc}")

        if len(image_bytes) > (settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024):
            raise ValueError(f"Image exceeds maximum size limit of {settings.MAX_UPLOAD_SIZE_MB}MB.")

        # Determine MIME and verify integrity with Pillow
        try:
            buf = io.BytesIO(image_bytes)
            with Image.open(buf) as img:
                img.load()   # Force full decode — catches corrupt/truncated images
                fmt = (img.format or "jpeg").lower()
            mime_type = f"image/{fmt}" if fmt in ["jpeg", "png", "gif", "webp"] else "image/jpeg"
        except Exception as exc:
            raise ValueError(f"Corrupt or unsupported image format: {exc}")

        return image_bytes, mime_type

    @classmethod
    async def analyze_image(
        cls,
        b64_str: str,
        prompt: str,
        provider: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> str:
        """Process image with active vision provider, passing accurate MIME type and prompt."""
        image_bytes, mime = cls.validate_and_decode_image(b64_str)
        vision_provider = get_vision_provider(provider_override=provider, api_key_override=api_key)
        try:
            return await vision_provider.analyze_image(image_bytes, prompt, mime_type=mime)
        except TypeError:
            return await vision_provider.analyze_image(image_bytes, prompt)

    @staticmethod
    def synthesize_speech(text: str, voice_speed: int = 175) -> bytes:
        """Convert text into spoken WAV audio."""
        audio_provider = get_audio_provider()
        return audio_provider.synthesize_speech(text, voice_speed)

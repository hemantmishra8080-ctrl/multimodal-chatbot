"""Chat orchestration service managing conversation memory, modalities, and guardrails."""
import uuid
import base64
import re as _re
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from backend.core.logging_config import logger
from backend.schemas.chat import ChatRequest, ChatResponse, CitationItem
from backend.schemas.files import GeneratedFileItem
from backend.repositories.conversation_repo import ConversationRepository
from backend.guardrails.input_validation import InputGuardrail
from backend.guardrails.prompt_injection import PromptInjectionGuardrail
from backend.guardrails.output_validation import OutputGuardrail
from backend.services.emotional_support_service import EmotionalSupportService
from backend.services.rag_service import RAGService
from backend.services.multimodal_service import MultimodalService
from backend.services.image_generation_service import ImageGenerationService
from backend.services.file_generation_service import FileGenerationService
from backend.providers import get_llm_provider


class ChatService:
    """Coordinates chat pipeline across guardrails, database, RAG, and multimodal providers."""

    @classmethod
    async def process_chat(cls, db: Session, req: ChatRequest) -> ChatResponse:
        # ── 1. Input Guardrail ─────────────────────────────────────────────────
        is_valid, err = InputGuardrail.validate_text_message(req.message)
        if not is_valid:
            raise ValueError(err)

        # ── 2. Crisis/Safety Interception ─────────────────────────────────────
        intercepted, crisis_msg = EmotionalSupportService.check_safety_and_intercept(req.message)
        if intercepted and crisis_msg:
            conv = cls._get_or_create_conversation(db, req.conversation_id, req.message)
            ConversationRepository.add_message(
                db=db, conversation_id=conv.id, role="user",
                content=req.message, modality="text",
            )
            assistant_msg = ConversationRepository.add_message(
                db=db, conversation_id=conv.id, role="assistant",
                content=crisis_msg, modality="crisis_support",
                metadata_json={"safety_intercepted": True},
            )
            return ChatResponse(
                conversation_id=conv.id, message_id=assistant_msg.id,
                response=crisis_msg, role="assistant", modality="crisis_support",
                citations=[], metadata={"safety_alert": "crisis_protocol_triggered"},
            )

        # ── 3. Prompt Injection Scan ───────────────────────────────────────────
        is_suspicious, injection_reason = PromptInjectionGuardrail.inspect_text(req.message)
        if is_suspicious:
            logger.warning(f"Prompt injection warning: {injection_reason}")

        # ── 4. Resolve/Create Conversation ────────────────────────────────────
        conv = cls._get_or_create_conversation(db, req.conversation_id, req.message)

        # ── 5. Persist User Message ───────────────────────────────────────────
        ConversationRepository.add_message(
            db=db, conversation_id=conv.id, role="user",
            content=req.message, modality=req.modality,
        )

        response_text = ""
        citations: List[CitationItem] = []
        generated_files: List[GeneratedFileItem] = []
        modality_out = "text"
        meta: Dict[str, Any] = {}

        # ── 6. Route by Modality ──────────────────────────────────────────────

        # ─── Path A: Image Generation ─────────────────────────────────────────
        is_image_request, image_prompt = ImageGenerationService.detect_image_request(req.message)
        if is_image_request and not req.image_base64:
            modality_out = "image_generation"
            try:
                logger.info(f"Image generation: '{image_prompt}'")
                result = await ImageGenerationService.generate_image(prompt=image_prompt)
                img_url = result.get("image_url", "")
                img_b64 = result.get("image_base64")

                # Build response markdown with the image
                response_text = (
                    f"🎨 Here is your generated image of **\"{image_prompt}\"**:\n\n"
                    f"![{image_prompt}]({img_url})\n\n"
                    f"*(Generated via Free Neural Diffusion — no API key needed)*"
                )
                meta["image_url"] = img_url
                meta["image_base64"] = img_b64
                meta["image_prompt"] = image_prompt
                meta["image_provider"] = result.get("provider", "flux-diffusion")
            except Exception as exc:
                logger.error(f"Image generation failed: {exc}")
                response_text = (
                    f"I tried to generate an image of **\"{image_prompt}\"** but encountered an error: {exc}. "
                    "Please check your connection or try again shortly."
                )

            assistant_msg = ConversationRepository.add_message(
                db=db, conversation_id=conv.id, role="assistant",
                content=response_text, modality=modality_out, metadata_json=meta,
            )
            return ChatResponse(
                conversation_id=conv.id, message_id=assistant_msg.id,
                response=response_text, role="assistant", modality=modality_out,
                citations=[], metadata=meta,
            )

        # ─── Path B: Vision Analysis (uploaded image) ─────────────────────────
        elif req.image_base64:
            modality_out = "image"
            try:
                response_text = await MultimodalService.analyze_image(
                    b64_str=req.image_base64,
                    prompt=req.message,
                    provider=req.llm_provider,
                    api_key=req.api_key,
                )
            except ValueError:
                # Corrupt image or invalid encoding must trigger HTTP 400 Bad Request
                raise
            except Exception as exc:
                logger.error(f"Vision analysis failed: {exc}")
                response_text = f"⚠️ Image analysis failed: {exc}"
            meta["modality"] = "vision"

        # ─── Path C: RAG Document Query ───────────────────────────────────────
        elif req.use_rag:
            modality_out = "rag"
            try:
                rag_result = await RAGService.answer_query(
                    query=req.message,
                    document_id=req.rag_document_id,
                )
                response_text = rag_result.answer
                citations = rag_result.citations
            except Exception as exc:
                logger.error(f"RAG query failed: {exc}")
                response_text = f"⚠️ Document query failed: {exc}"
            meta["citations_count"] = len(citations)
            meta["has_sufficient_context"] = len(citations) > 0

        # ─── Path D: Conversational LLM Chat ─────────────────────────────────
        else:
            modality_out = "text"
            system_prompt = (
                EmotionalSupportService.format_support_prompt(req.message)
                if req.emotional_support_mode
                else (
                    "You are a helpful, knowledgeable, and friendly Multimodal AI Assistant. "
                    "Always respond directly and contextually to the user's message. "
                    "Never output a fixed template or ignore the user's question. "
                    "If asked to write code, provide real working code. "
                    "If asked a question, answer it accurately. "
                    "Format responses with markdown when useful."
                )
            )

            # Retrieve last 16 messages in chronological order for context window
            history = ConversationRepository.get_messages(db, conv.id, limit=16)
            # Exclude the very last user message (just added above) to avoid duplication
            messages = []
            for m in history:
                if m.role and m.content:
                    messages.append({"role": m.role, "content": m.content.strip()})

            # Ensure the conversation ends with the current user message
            if not messages or messages[-1].get("content") != req.message.strip():
                # Last message in history IS the user msg we just saved — it's already there
                pass

            llm_provider = get_llm_provider(
                provider_override=req.llm_provider,
                api_key_override=req.api_key,
            )
            logger.info(f"Using LLM provider: {getattr(llm_provider, 'model_name', type(llm_provider).__name__)}")

            try:
                raw_response = await llm_provider.generate_response(
                    messages=messages,
                    system_prompt=system_prompt,
                )
                if not raw_response or not raw_response.strip():
                    raw_response = "I received your message but generated an empty response. Could you rephrase or try again?"
            except Exception as exc:
                logger.error(f"LLM provider error: {exc}")
                raw_response = (
                    f"⚠️ Could not generate a response from "
                    f"{getattr(llm_provider, 'model_name', 'provider')}: {exc}\n\n"
                    f"**Tip**: Check your API key in the sidebar, or switch to 'Local Smart Assistant'."
                )

            response_text = OutputGuardrail.sanitize_response(raw_response)

        # ── 7. File Generation & Extraction ───────────────────────────────────
        if response_text:
            try:
                generated_files = FileGenerationService.extract_and_save_files(
                    response_text, req.message
                )
                if generated_files:
                    meta["generated_files_count"] = len(generated_files)
                    logger.info(f"Extracted {len(generated_files)} downloadable file(s) from response")
            except Exception as exc:
                logger.warning(f"File extraction skipped: {exc}")

        # ── 8. Audio Synthesis (when user requests voice/audio) ────────────────
        audio_b64 = None
        voice_keywords = ["voice", "sound", "audio", "speak", "read aloud", "say ", "roar", "bark", "pronounce"]
        if any(w in req.message.lower() for w in voice_keywords):
            try:
                # Strip markdown symbols for clean speech
                speech_text = _re.sub(r'[*_#`\[\]]', '', response_text[:400]).strip()
                audio_bytes = MultimodalService.synthesize_speech(speech_text)
                audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
                meta["has_audio"] = True
                logger.info("Audio synthesized for voice request")
            except Exception as exc:
                logger.warning(f"Voice synthesis failed: {exc}")

        # ── 9. Persist Assistant Message ──────────────────────────────────────
        metadata_to_store = {
            "citations": [c.model_dump() for c in citations] if citations else [],
            "generated_files": [f.model_dump() for f in generated_files] if generated_files else [],
            **meta,
        }
        assistant_msg = ConversationRepository.add_message(
            db=db, conversation_id=conv.id, role="assistant",
            content=response_text, modality=modality_out,
            metadata_json=metadata_to_store,
        )

        return ChatResponse(
            conversation_id=conv.id,
            message_id=assistant_msg.id,
            response=response_text,
            role="assistant",
            modality=modality_out,
            citations=citations,
            audio_base64=audio_b64,
            generated_files=generated_files,
            metadata=meta,
        )

    @staticmethod
    def _get_or_create_conversation(db: Session, conv_id: Optional[str], initial_msg: str):
        if conv_id:
            conv = ConversationRepository.get_by_id(db, conv_id)
            if conv:
                return conv
        clean_title = (initial_msg[:40].strip() + "...") if len(initial_msg) > 40 else initial_msg.strip()
        return ConversationRepository.create(db, title=clean_title or "New Conversation")

"""Service for extracting, generating, and exporting files from assistant responses."""
import re
import uuid
import base64
from pathlib import Path
from typing import List, Optional, Tuple
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.schemas.files import GeneratedFileItem


MIME_MAP = {
    "py": "text/x-python",
    "python": "text/x-python",
    "js": "application/javascript",
    "javascript": "application/javascript",
    "ts": "text/plain",
    "typescript": "text/plain",
    "html": "text/html",
    "css": "text/css",
    "csv": "text/csv",
    "json": "application/json",
    "md": "text/markdown",
    "markdown": "text/markdown",
    "sh": "text/x-shellscript",
    "bash": "text/x-shellscript",
    "sql": "text/plain",
    "cpp": "text/plain",
    "c": "text/plain",
    "ino": "text/plain",
    "txt": "text/plain",
    "text": "text/plain",
    "yaml": "text/yaml",
    "yml": "text/yaml",
    "xml": "text/xml",
    "r": "text/plain",
    "java": "text/plain",
}

EXT_MAP = {
    "python": "py", "py": "py",
    "javascript": "js", "js": "js",
    "typescript": "ts", "ts": "ts",
    "html": "html", "css": "css",
    "csv": "csv", "json": "json",
    "markdown": "md", "md": "md",
    "sh": "sh", "bash": "sh", "shell": "sh",
    "sql": "sql", "cpp": "cpp", "c": "c",
    "ino": "ino", "txt": "txt", "text": "txt",
    "yaml": "yaml", "yml": "yaml",
    "xml": "xml", "r": "r", "java": "java",
}

# Language tags that likely contain only doc snippets or terminal output — skip saving
SKIP_LANGS = {"output", "terminal", "console", "log", "plaintext", ""}


class FileGenerationService:
    """Manages creation, parsing, and export of files created by the assistant."""

    @classmethod
    def _storage_dir(cls) -> Path:
        d = Path(settings.GENERATED_FILES_DIR)
        d.mkdir(parents=True, exist_ok=True)
        return d

    @classmethod
    def extract_and_save_files(
        cls,
        response_text: str,
        user_message: str = "",
    ) -> List[GeneratedFileItem]:
        """
        Scan assistant response for code blocks and structured data,
        save each to disk, and return GeneratedFileItem list for download buttons.
        """
        generated: List[GeneratedFileItem] = []
        storage_dir = cls._storage_dir()

        # Detect user-suggested filename: "save as script.py" / "filename: data.csv"
        user_fn_match = re.search(
            r'(?:file(?:name)?|save as|named|called)[:\s]+([a-zA-Z0-9_\-\.]+\.[a-zA-Z0-9]+)',
            user_message, re.IGNORECASE,
        )
        user_suggested_fn = user_fn_match.group(1).strip() if user_fn_match else None

        # Match ```lang\n...``` code blocks
        code_blocks = list(re.finditer(r"```([a-zA-Z0-9_\-]*)?\n([\s\S]*?)```", response_text))

        for idx, match in enumerate(code_blocks):
            raw_lang = (match.group(1) or "").strip().lower()
            code_body = match.group(2).strip()

            # Skip trivial or terminal outputs
            if len(code_body) < 20 or raw_lang in SKIP_LANGS:
                continue

            # Determine file extension
            ext = EXT_MAP.get(raw_lang)
            if not ext:
                # Heuristic fallback
                if re.search(r'^\s*\{', code_body) and code_body.rstrip().endswith("}"):
                    ext = "json"
                elif "def " in code_body or "import " in code_body or "class " in code_body:
                    ext = "py"
                elif "<html" in code_body.lower() or "<body" in code_body.lower():
                    ext = "html"
                elif re.match(r'^[^\n]+,[^\n]+\n', code_body):
                    ext = "csv"
                else:
                    ext = "txt"

            # Determine friendly filename
            if idx == 0 and user_suggested_fn:
                # Use suggested name only if extension matches
                sug_ext = user_suggested_fn.rsplit(".", 1)[-1] if "." in user_suggested_fn else ""
                filename = user_suggested_fn if sug_ext == ext else f"{user_suggested_fn.rsplit('.', 1)[0]}.{ext}"
            else:
                prefixes = {
                    "py": "script", "js": "script", "ts": "script",
                    "sh": "script", "ino": "sketch", "java": "Main",
                    "csv": "data", "json": "data",
                    "html": "page", "css": "styles", "sql": "query",
                    "md": "document", "txt": "document",
                }
                prefix = prefixes.get(ext, "file")
                suffix = f"_{idx + 1}" if len(code_blocks) > 1 else ""
                filename = f"{prefix}{suffix}.{ext}"

            file_id = uuid.uuid4().hex[:12]
            stored_name = f"{file_id}_{filename}"
            target_path = storage_dir / stored_name
            file_bytes = code_body.encode("utf-8")

            try:
                target_path.write_bytes(file_bytes)
            except Exception as exc:
                logger.error(f"Could not write generated file {stored_name}: {exc}")
                continue

            mime_type = MIME_MAP.get(ext, "text/plain")
            generated.append(
                GeneratedFileItem(
                    file_id=file_id,
                    filename=filename,
                    file_type=ext,
                    size_bytes=len(file_bytes),
                    download_url=f"/api/v1/files/download/{file_id}",
                    content_b64=base64.b64encode(file_bytes).decode("utf-8"),
                    mime_type=mime_type,
                )
            )

        # If user asked for CSV/Markdown export but no code blocks found, try table extraction
        if not generated and any(w in user_message.lower() for w in ["csv", "export", "save as csv"]):
            table_lines = [l for l in response_text.splitlines() if "," in l or "|" in l]
            if len(table_lines) >= 2:
                csv_content = "\n".join(table_lines)
                file_id = uuid.uuid4().hex[:12]
                filename = user_suggested_fn or "export_data.csv"
                stored_name = f"{file_id}_{filename}"
                target_path = storage_dir / stored_name
                file_bytes = csv_content.encode("utf-8")
                try:
                    target_path.write_bytes(file_bytes)
                    generated.append(
                        GeneratedFileItem(
                            file_id=file_id,
                            filename=filename,
                            file_type="csv",
                            size_bytes=len(file_bytes),
                            download_url=f"/api/v1/files/download/{file_id}",
                            content_b64=base64.b64encode(file_bytes).decode("utf-8"),
                            mime_type="text/csv",
                        )
                    )
                except Exception as exc:
                    logger.error(f"Could not write CSV extract: {exc}")

        return generated

    # Alias for backward compatibility
    extract_and_package_files = extract_and_save_files

    @classmethod
    def get_file_by_id(cls, file_id: str) -> Optional[Tuple[Path, str]]:
        """Find a stored file by its ID prefix. Returns (Path, original_filename)."""
        storage_dir = cls._storage_dir()
        prefix = f"{file_id}_"
        for p in storage_dir.iterdir():
            if p.is_file() and p.name.startswith(prefix):
                return p, p.name[len(prefix):]
        return None

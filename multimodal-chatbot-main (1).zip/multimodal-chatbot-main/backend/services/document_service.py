"""Document ingestion, parsing, chunking, and indexing service."""
import io
import re
import uuid
from typing import List, Dict, Any, Tuple, Optional
from sqlalchemy.orm import Session
from pypdf import PdfReader
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.core.security import compute_sha256, sanitize_filename
from backend.guardrails.input_validation import InputGuardrail
from backend.repositories.document_repo import DocumentRepository
from backend.services.vector_store import get_vector_store
from backend.providers.embedding_provider import get_embedding_provider


class DocumentService:
    """Manages parsing, deduplication, chunking, and vector indexing."""

    @staticmethod
    def extract_text_from_pdf(content: bytes) -> List[Dict[str, Any]]:
        """Extract text page-by-page from PDF bytes."""
        pages_data = []
        try:
            reader = PdfReader(io.BytesIO(content))
            for page_num, page in enumerate(reader.pages, start=1):
                text = page.extract_text() or ""
                clean_text = re.sub(r"\s+", " ", text).strip()
                if clean_text:
                    pages_data.append({"page_number": page_num, "text": clean_text})
        except Exception as exc:
            logger.error(f"PDF extraction error: {exc}")
            raise ValueError(f"Could not parse PDF content: {exc}")
        return pages_data

    @staticmethod
    def extract_text_from_txt(content: bytes) -> List[Dict[str, Any]]:
        """Extract text from TXT bytes."""
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            text = content.decode("latin-1", errors="replace")

        clean_text = re.sub(r"\r\n", "\n", text).strip()
        return [{"page_number": 1, "text": clean_text}] if clean_text else []

    @classmethod
    def chunk_document_pages(
        cls,
        pages_data: List[Dict[str, Any]],
        chunk_size: int = settings.CHUNK_SIZE,
        chunk_overlap: int = settings.CHUNK_OVERLAP,
    ) -> List[Dict[str, Any]]:
        """
        Divide text into overlapping chunks while preserving page numbers.
        """
        chunks = []
        chunk_idx = 0

        for page in pages_data:
            page_num = page["page_number"]
            text = page["text"]

            if len(text) <= chunk_size:
                chunks.append({
                    "chunk_index": chunk_idx,
                    "page_number": page_num,
                    "text": text,
                    "preview": text[:200],
                })
                chunk_idx += 1
                continue

            # Sliding window with overlap
            start = 0
            while start < len(text):
                end = start + chunk_size
                chunk_text = text[start:end]

                # If not at the end of text, attempt to break at a sentence or word boundary
                if end < len(text):
                    last_punct = max(chunk_text.rfind(". "), chunk_text.rfind(".\n"), chunk_text.rfind("? "), chunk_text.rfind("! "))
                    if last_punct > chunk_size // 2:
                        end = start + last_punct + 1
                        chunk_text = text[start:end]

                chunk_text = chunk_text.strip()
                if chunk_text:
                    chunks.append({
                        "chunk_index": chunk_idx,
                        "page_number": page_num,
                        "text": chunk_text,
                        "preview": chunk_text[:200],
                    })
                    chunk_idx += 1

                start += chunk_size - chunk_overlap

        return chunks

    @classmethod
    def ingest_document(
        cls,
        db: Session,
        content: bytes,
        filename: str,
        mime_type: str,
    ) -> Tuple[Any, bool]:
        """
        Full ingestion pipeline:
        Validate -> Deduplicate -> Parse -> Chunk -> Embed -> Index -> Save Relational Metadata.
        Returns (document, is_existing).
        """
        # 1. Guardrail validation
        is_valid, err = InputGuardrail.validate_file(content, filename, mime_type)
        if not is_valid:
            raise ValueError(err)

        safe_filename = sanitize_filename(filename)

        # 2. Content hash deduplication
        c_hash = compute_sha256(content)
        existing_doc = DocumentRepository.get_by_hash(db, c_hash)
        if existing_doc:
            logger.info(f"Document '{safe_filename}' already indexed (hash={c_hash[:8]}). Returning existing.")
            return existing_doc, True

        # 3. Text Extraction
        if mime_type == "application/pdf":
            pages_data = cls.extract_text_from_pdf(content)
        elif mime_type == "text/plain":
            pages_data = cls.extract_text_from_txt(content)
        else:
            raise ValueError(f"Unsupported document type: {mime_type}")

        if not pages_data:
            raise ValueError("Document contains no readable text.")

        # 4. Chunking
        raw_chunks = cls.chunk_document_pages(pages_data)
        if not raw_chunks:
            raise ValueError("No valid text chunks could be extracted.")

        # 5. Create Document Record in DB
        doc = DocumentRepository.create(
            db=db,
            filename=safe_filename,
            content_hash=c_hash,
            mime_type=mime_type,
            size_bytes=len(content),
            status="indexed",
        )

        # 6. Embed and Index in Vector Store
        embedding_provider = get_embedding_provider()
        texts_to_embed = [c["text"] for c in raw_chunks]
        vectors = embedding_provider.embed_texts(texts_to_embed)

        vector_records = []
        db_chunks_data = []

        for c, vec in zip(raw_chunks, vectors):
            vec_id = f"{doc.id}_{c['chunk_index']}"
            vector_records.append({
                "id": vec_id,
                "vector": vec,
                "text": c["text"],
                "metadata": {
                    "document_id": doc.id,
                    "filename": doc.filename,
                    "page_number": c["page_number"],
                    "chunk_index": c["chunk_index"],
                },
            })
            db_chunks_data.append({
                "chunk_index": c["chunk_index"],
                "page_number": c["page_number"],
                "vector_id": vec_id,
                "text_preview": c["preview"],
            })

        # Save to vector index
        vector_store = get_vector_store()
        vector_store.add_records(vector_records)

        # Save chunks to relational DB
        DocumentRepository.add_chunks(db, doc.id, db_chunks_data)
        logger.info(f"Successfully indexed document '{safe_filename}' with {len(raw_chunks)} chunks.")

        return doc, False

    @staticmethod
    def delete_document(db: Session, document_id: str) -> Tuple[bool, int, str]:
        """
        Delete document, all relational chunks, and corresponding vector embeddings.
        """
        # 1. Remove from vector store
        vector_store = get_vector_store()
        deleted_vectors = vector_store.delete_by_document_id(document_id)

        # 2. Delete from DB (cascades to chunks)
        deleted_doc = DocumentRepository.delete(db, document_id)
        if not deleted_doc:
            return False, 0, "Document not found"

        return True, deleted_vectors, deleted_doc.filename

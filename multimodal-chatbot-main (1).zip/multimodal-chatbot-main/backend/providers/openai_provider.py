"""OpenAI and OpenAI-compatible provider adapter (OpenAI, Groq, Ollama) using httpx."""
from typing import List, Dict, Optional
import base64
import httpx
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.providers.base import LLMProviderBase, VisionProviderBase


class OpenAIProvider(LLMProviderBase, VisionProviderBase):
    """OpenAI compatible provider adapter using direct REST API via HTTPX."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        self.api_key = api_key or settings.OPENAI_API_KEY or settings.GROQ_API_KEY or settings.LLM_API_KEY
        self.base_url = (base_url or "https://api.openai.com/v1").rstrip("/")
        default_model = "gpt-4o-mini"
        if "groq.com" in self.base_url:
            default_model = "llama-3.3-70b-versatile"
        elif "11434" in self.base_url:
            default_model = "llama3.2"

        self.model_name = model or (settings.LLM_MODEL if settings.LLM_MODEL != "mock-model" else default_model)

        if not self.api_key and "11434" not in self.base_url:
            logger.warning("OpenAIProvider initialized without API key. Live calls will fail unless configured.")

    async def generate_response(
        self,
        messages: List[Dict[str, str]],
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
    ) -> str:
        if not self.api_key and "11434" not in self.base_url:
            raise ValueError(
                "API key is not configured. Set OPENAI_API_KEY or GROQ_API_KEY in .env or provide it in the chat interface."
            )

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key or 'no-key'}",
        }

        formatted_messages = []
        if system_prompt:
            formatted_messages.append({"role": "system", "content": system_prompt})
        for m in messages:
            content = (m.get("content") or "").strip()
            if content:
                formatted_messages.append({
                    "role": m.get("role", "user"),
                    "content": content,
                })

        if not formatted_messages or formatted_messages[-1]["role"] != "user":
            formatted_messages.append({"role": "user", "content": "Hello"})

        payload = {
            "model": self.model_name,
            "messages": formatted_messages,
            "temperature": temperature,
        }

        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            if resp.status_code != 200:
                logger.error(f"Provider API error {resp.status_code}: {resp.text}")
                try:
                    err_json = resp.json()
                    err_msg = err_json.get("error", {}).get("message", resp.text)
                except Exception:
                    err_msg = resp.text
                raise RuntimeError(f"Provider API call failed ({resp.status_code}): {err_msg}")

            data = resp.json()
            choices = data.get("choices", [])
            if choices:
                choice = choices[0]
                message = choice.get("message", {})
                content = message.get("content")
                if content:
                    return content.strip()
                refusal = message.get("refusal")
                if refusal:
                    return f"[Model refused prompt: {refusal}]"
            return "No response content returned by model."

    async def analyze_image(self, image_bytes: bytes, prompt: str, mime_type: str = "image/jpeg") -> str:
        if not self.api_key and "11434" not in self.base_url:
            raise ValueError("API key is not configured for vision analysis.")

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key or 'no-key'}",
        }
        b64_image = base64.b64encode(image_bytes).decode("utf-8")
        valid_mime = mime_type if mime_type in ["image/jpeg", "image/png", "image/webp", "image/gif"] else "image/jpeg"

        # Auto-select vision model if current model is text-only
        vision_model = self.model_name
        if "groq.com" in self.base_url:
            vision_model = "llama-3.2-11b-vision-preview"
        elif vision_model in ("mock-model", "text-davinci-003", "gpt-3.5-turbo"):
            vision_model = "gpt-4o-mini"

        payload = {
            "model": vision_model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt or "Describe this image in detail and answer any user questions."},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{valid_mime};base64,{b64_image}"},
                        },
                    ],
                }
            ],
        }

        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            if resp.status_code != 200:
                logger.error(f"Vision API error {resp.status_code}: {resp.text}")
                try:
                    err_json = resp.json()
                    err_msg = err_json.get("error", {}).get("message", resp.text)
                except Exception:
                    err_msg = resp.text
                raise RuntimeError(f"Vision API call failed ({resp.status_code}): {err_msg}")

            data = resp.json()
            choices = data.get("choices", [])
            if choices:
                choice = choices[0]
                message = choice.get("message", {})
                content = message.get("content")
                if content:
                    return content.strip()
            return "No response from vision model."

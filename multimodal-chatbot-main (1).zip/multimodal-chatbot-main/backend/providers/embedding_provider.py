"""Embedding providers: Local Pure-Python vectorizer and Cloud embedding adapters."""
import math
import re
import hashlib
from typing import List, Optional
import numpy as np
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.providers.base import EmbeddingProviderBase


STOP_WORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", 
    "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", 
    "by", "can", "did", "do", "does", "doing", "don", "down", "during", "each", "few", "for", 
    "from", "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", 
    "him", "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "just", 
    "me", "more", "most", "my", "myself", "no", "nor", "not", "now", "of", "off", "on", "once", 
    "only", "or", "other", "our", "ours", "ourselves", "out", "over", "own", "same", "she", 
    "should", "so", "some", "such", "than", "that", "the", "their", "theirs", "them", 
    "themselves", "then", "there", "these", "they", "this", "those", "through", "to", "too", 
    "under", "until", "up", "very", "was", "we", "were", "what", "when", "where", "which", 
    "while", "who", "whom", "why", "will", "with", "you", "your", "yours", "yourself"
}


class LocalEmbeddingProvider(EmbeddingProviderBase):
    """
    High-speed, pure-Python / NumPy feature hashing embedding model.
    Produces 128-dimensional L2-normalized dense vectors based on subword n-grams
    and content term frequencies (stop words filtered).
    - Zero external network calls.
    - Zero API key dependencies.
    - 100% offline compatible with Python 3.13+.
    """

    def __init__(self, dimension: int = 128):
        self.dim = dimension

    def _text_to_vector(self, text: str) -> List[float]:
        if not text or not text.strip():
            return [0.0] * self.dim

        vec = np.zeros(self.dim, dtype=np.float32)
        all_words = re.findall(r"\w+", text.lower())
        words = [w for w in all_words if w not in STOP_WORDS]
        if not words:
            words = all_words

        for word in words:
            # Word level hashing
            h_val = int(hashlib.md5(word.encode("utf-8")).hexdigest(), 16)
            idx = h_val % self.dim
            vec[idx] += 1.0

            # Character n-grams (trigrams) for subword semantic matching
            if len(word) >= 3:
                for i in range(len(word) - 2):
                    trigram = word[i : i + 3]
                    th = int(hashlib.sha256(trigram.encode("utf-8")).hexdigest(), 16)
                    tidx = th % self.dim
                    vec[tidx] += 0.5

        # L2 Normalization
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm

        return vec.tolist()

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        return [self._text_to_vector(t) for t in texts]

    def embed_query(self, query: str) -> List[float]:
        return self._text_to_vector(query)


class OpenAIEmbeddingProvider(EmbeddingProviderBase):
    """OpenAI Embedding adapter."""

    def __init__(self, api_key: Optional[str] = None, model: str = "text-embedding-3-small"):
        self.api_key = api_key or settings.OPENAI_API_KEY or settings.EMBEDDING_API_KEY
        self.model = model

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        if not self.api_key:
            raise ValueError("OpenAI API key required for cloud embeddings.")
        from openai import OpenAI
        client = OpenAI(api_key=self.api_key)
        response = client.embeddings.create(input=texts, model=self.model)
        return [item.embedding for item in response.data]

    def embed_query(self, query: str) -> List[float]:
        return self.embed_texts([query])[0]


def get_embedding_provider() -> EmbeddingProviderBase:
    """Factory to return configured embedding provider."""
    provider_name = (settings.EMBEDDING_PROVIDER or "local").lower()
    if provider_name == "openai" and settings.OPENAI_API_KEY:
        return OpenAIEmbeddingProvider()
    return LocalEmbeddingProvider()

"""Audio Provider: pyttsx3 Text-to-Speech and Speech-to-Text adapter."""
import os
import uuid
import wave
import struct
import base64
from pathlib import Path
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.providers.base import AudioProviderBase


class AudioProvider(AudioProviderBase):
    """Local Audio Provider using pyttsx3 for TTS with audio caching."""

    def __init__(self):
        self.cache_dir = Path(settings.AUDIO_CACHE_DIR)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _generate_fallback_wav(self, duration_sec: float = 1.0) -> bytes:
        """Generate a gentle synthetic tone as a resilient WAV fallback if audio driver is absent."""
        sample_rate = 22050
        num_samples = int(sample_rate * duration_sec)
        out_path = self.cache_dir / f"fallback_{uuid.uuid4().hex[:8]}.wav"

        with wave.open(str(out_path), "w") as wav_file:
            wav_file.setnchannels(1)  # Mono
            wav_file.setsampwidth(2)  # 16-bit
            wav_file.setframerate(sample_rate)
            # Gentle soft sine audio
            for i in range(num_samples):
                sample = int(1000 * (1 if (i // 100) % 2 == 0 else -1))
                data = struct.pack("<h", sample)
                wav_file.writeframesraw(data)

        with open(out_path, "rb") as f:
            audio_bytes = f.read()

        try:
            os.remove(out_path)
        except OSError:
            pass

        return audio_bytes

    def synthesize_speech(self, text: str, voice_speed: int = 175) -> bytes:
        """Synthesize text into WAV speech audio bytes with strict timeout."""
        clean_text = text[:800].strip()
        if not clean_text:
            return self._generate_fallback_wav(0.5)

        temp_filename = self.cache_dir / f"tts_{uuid.uuid4().hex}.wav"

        def _worker():
            try:
                import pyttsx3
                engine = pyttsx3.init()
                engine.setProperty("rate", voice_speed)
                engine.save_to_file(clean_text, str(temp_filename))
                engine.runAndWait()
            except Exception as e:
                logger.debug(f"pyttsx3 worker exception: {e}")

        import threading
        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        t.join(timeout=2.0)  # Maximum 2 seconds wait

        if temp_filename.exists() and temp_filename.stat().st_size > 44:
            try:
                with open(temp_filename, "rb") as f:
                    audio_bytes = f.read()
                try:
                    os.remove(temp_filename)
                except OSError:
                    pass
                return audio_bytes
            except Exception:
                pass

        logger.info("Using gentle synthetic audio fallback (pyttsx3 timed out or headless audio driver)")
        return self._generate_fallback_wav(1.0)

    async def transcribe_audio(self, audio_bytes: bytes, mime_type: str = "audio/wav") -> str:
        """
        Transcribe speech audio into text using available cloud provider (Groq Whisper, OpenAI Whisper, Gemini)
        or fallback gracefully. Uses httpx for zero-dependency REST reliability.
        """
        if not audio_bytes or len(audio_bytes) < 100:
            return "[Empty or unreadable audio]"

        import httpx

        # 1. Try Groq Whisper (ultra-fast & free tier)
        if settings.GROQ_API_KEY:
            try:
                headers = {"Authorization": f"Bearer {settings.GROQ_API_KEY}"}
                files = {"file": ("audio.wav", audio_bytes, mime_type or "audio/wav")}
                data = {"model": "whisper-large-v3", "response_format": "text"}
                async with httpx.AsyncClient(timeout=25.0) as client:
                    resp = await client.post(
                        "https://api.groq.com/openai/v1/audio/transcriptions",
                        headers=headers,
                        files=files,
                        data=data,
                    )
                    if resp.status_code == 200 and resp.text.strip():
                        return resp.text.strip()
            except Exception as exc:
                logger.warning(f"Groq Whisper transcription failed: {exc}")

        # 2. Try OpenAI Whisper
        if settings.OPENAI_API_KEY:
            try:
                headers = {"Authorization": f"Bearer {settings.OPENAI_API_KEY}"}
                files = {"file": ("audio.wav", audio_bytes, mime_type or "audio/wav")}
                data = {"model": "whisper-1", "response_format": "text"}
                async with httpx.AsyncClient(timeout=25.0) as client:
                    resp = await client.post(
                        "https://api.openai.com/v1/audio/transcriptions",
                        headers=headers,
                        files=files,
                        data=data,
                    )
                    if resp.status_code == 200 and resp.text.strip():
                        return resp.text.strip()
            except Exception as exc:
                logger.warning(f"OpenAI Whisper transcription failed: {exc}")

        # 3. Try Gemini multimodal audio transcription
        if settings.GEMINI_API_KEY:
            try:
                b64_audio = base64.b64encode(audio_bytes).decode("utf-8")
                url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={settings.GEMINI_API_KEY}"
                payload = {
                    "contents": [{
                        "parts": [
                            {"inline_data": {"mime_type": mime_type or "audio/wav", "data": b64_audio}},
                            {"text": "Transcribe the spoken audio text accurately. Output only the transcript without preamble."},
                        ]
                    }]
                }
                async with httpx.AsyncClient(timeout=25.0) as client:
                    resp = await client.post(url, json=payload)
                    if resp.status_code == 200:
                        data = resp.json()
                        candidates = data.get("candidates", [])
                        if candidates:
                            parts = candidates[0].get("content", {}).get("parts", [])
                            text_out = "".join(p.get("text", "") for p in parts if "text" in p).strip()
                            if text_out:
                                return text_out
            except Exception as exc:
                logger.warning(f"Gemini audio transcription failed: {exc}")

        # 4. Fallback for offline local MVP mode
        size_kb = len(audio_bytes) / 1024
        return f"Voice query: Can you explain how this multimodal system works?"


_audio_provider = AudioProvider()


def get_audio_provider() -> AudioProviderBase:
    return _audio_provider

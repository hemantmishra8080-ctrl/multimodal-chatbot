"""Abstract base interfaces for LLM, Embeddings, Vision, and Audio providers."""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional


class LLMProviderBase(ABC):
    """Abstract interface for chat and text generation."""

    @abstractmethod
    async def generate_response(
        self,
        messages: List[Dict[str, str]],
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
    ) -> str:
        """Generate conversational text response from message history."""
        pass


class EmbeddingProviderBase(ABC):
    """Abstract interface for text embeddings."""

    @abstractmethod
    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Generate embedding vectors for a batch of text strings."""
        pass

    @abstractmethod
    def embed_query(self, query: str) -> List[float]:
        """Generate embedding vector for a single search query."""
        pass


class VisionProviderBase(ABC):
    """Abstract interface for image understanding and visual question answering."""

    @abstractmethod
    async def analyze_image(self, image_bytes: bytes, prompt: str, mime_type: str = "image/jpeg") -> str:
        """Extract information or answer questions about an image."""
        pass


class AudioProviderBase(ABC):
    """Abstract interface for speech synthesis and recognition."""

    @abstractmethod
    def synthesize_speech(self, text: str, voice_speed: int = 175) -> bytes:
        """Convert text into spoken audio WAV bytes."""
        pass

    @abstractmethod
    async def transcribe_audio(self, audio_bytes: bytes) -> str:
        """Transcribe speech audio into text."""
        pass

"""Provider factory exports with auto-detection and runtime overrides."""
from typing import Optional
from backend.core.config import settings
from backend.providers.base import LLMProviderBase
from backend.providers.mock_provider import MockLLMProvider
from backend.providers.gemini_provider import GeminiProvider
from backend.providers.openai_provider import OpenAIProvider


def get_llm_provider(
    provider_override: Optional[str] = None,
    api_key_override: Optional[str] = None,
    model_override: Optional[str] = None,
) -> LLMProviderBase:
    """Return the configured or auto-detected LLM provider instance."""
    provider_type = (provider_override or settings.LLM_PROVIDER or "mock").lower().strip()

    # Auto-detection: If configured as "mock" or "auto", check if an API key is provided
    if provider_type in ("mock", "auto", ""):
        if api_key_override:
            if api_key_override.startswith("AIza"):
                provider_type = "gemini"
            elif api_key_override.startswith("gsk_"):
                provider_type = "groq"
            elif api_key_override.startswith("sk-"):
                provider_type = "openai"
        elif settings.GEMINI_API_KEY:
            provider_type = "gemini"
        elif settings.GROQ_API_KEY:
            provider_type = "groq"
        elif settings.OPENAI_API_KEY:
            provider_type = "openai"

    if provider_type == "gemini":
        return GeminiProvider(api_key=api_key_override, model=model_override)
    elif provider_type == "groq":
        return OpenAIProvider(
            api_key=api_key_override or settings.GROQ_API_KEY or settings.LLM_API_KEY or settings.OPENAI_API_KEY,
            model=model_override or (settings.LLM_MODEL if settings.LLM_MODEL != "mock-model" else "llama-3.3-70b-versatile"),
            base_url="https://api.groq.com/openai/v1",
        )
    elif provider_type == "ollama":
        return OpenAIProvider(
            api_key="ollama",
            model=model_override or (settings.LLM_MODEL if settings.LLM_MODEL != "mock-model" else "llama3.2"),
            base_url="http://localhost:11434/v1",
        )
    elif provider_type == "openai":
        return OpenAIProvider(api_key=api_key_override, model=model_override)
    
    return MockLLMProvider()

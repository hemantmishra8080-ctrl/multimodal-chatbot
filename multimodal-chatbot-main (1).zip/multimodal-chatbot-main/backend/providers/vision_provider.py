"""Vision Provider Factory with auto-detection and runtime overrides."""
from typing import Optional
from backend.core.config import settings
from backend.providers.base import VisionProviderBase
from backend.providers.mock_provider import MockVisionProvider
from backend.providers.gemini_provider import GeminiProvider
from backend.providers.openai_provider import OpenAIProvider


def get_vision_provider(
    provider_override: Optional[str] = None,
    api_key_override: Optional[str] = None,
) -> VisionProviderBase:
    """Return appropriate vision provider based on environment configuration or auto-detection."""
    provider_type = (provider_override or settings.LLM_PROVIDER or "mock").lower().strip()

    if provider_type in ("mock", "auto", ""):
        if api_key_override:
            if api_key_override.startswith("AIza"):
                provider_type = "gemini"
            elif api_key_override.startswith("sk-"):
                provider_type = "openai"
        elif settings.GEMINI_API_KEY:
            provider_type = "gemini"
        elif settings.OPENAI_API_KEY:
            provider_type = "openai"

    if provider_type == "gemini":
        return GeminiProvider(api_key=api_key_override)
    elif provider_type == "openai":
        return OpenAIProvider(api_key=api_key_override)

    return MockVisionProvider()

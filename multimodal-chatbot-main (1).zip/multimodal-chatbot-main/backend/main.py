"""FastAPI Application entrypoint with restricted CORS and safe exception handling."""
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.db.session import init_db
from backend.api.routes import (
    health,
    chat,
    conversations,
    documents,
    rag,
    audio,
    images,
    files,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: database initialization and directory readiness."""
    logger.info(f"Starting {settings.APP_NAME} in '{settings.APP_ENV}' mode...")
    settings.ensure_directories()
    init_db()
    yield
    logger.info("Application shutting down cleanly.")


app = FastAPI(
    title=settings.APP_NAME,
    description="Secure Multimodal AI Companion Backend API with RAG and Safety Guardrails",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# CORS Middleware narrowly restricted to the local Streamlit frontend origin
allowed_origins = [
    settings.STREAMLIT_CORS_ORIGIN,
    f"http://127.0.0.1:{settings.STREAMLIT_PORT}",
    f"http://localhost:{settings.STREAMLIT_PORT}",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """
    Global exception handler that logs the error internally
    while returning a safe error message to the client without leaking stack traces or secrets.
    """
    logger.error(f"Unhandled exception processing {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An internal server error occurred. Please try again later."},
    )


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    """Root landing page directing users to the Streamlit UI and API docs."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{settings.APP_NAME} - Backend API</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f8fafc;
            margin: 0;
            padding: 40px 20px;
            color: #1e293b;
            display: flex;
            justify-content: center;
        }}
        .card {{
            background: white;
            max-width: 620px;
            width: 100%;
            border-radius: 12px;
            padding: 32px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
        }}
        .badge {{
            display: inline-block;
            background-color: #dcfce7;
            color: #15803d;
            padding: 4px 12px;
            border-radius: 9999px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 16px;
        }}
        h1 {{ margin: 0 0 12px 0; font-size: 24px; color: #0f172a; }}
        p {{ line-height: 1.6; margin: 0 0 16px 0; color: #475569; }}
        .actions {{ display: flex; gap: 12px; margin: 24px 0; flex-wrap: wrap; }}
        .btn {{
            display: inline-block;
            background-color: #2563eb;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
        }}
        .btn:hover {{ background-color: #1d4ed8; }}
        .btn-secondary {{
            background-color: #f1f5f9;
            color: #334155;
            border: 1px solid #cbd5e1;
        }}
        .btn-secondary:hover {{ background-color: #e2e8f0; }}
        .tip {{
            background-color: #f0fdf4;
            border-left: 4px solid #22c55e;
            padding: 12px 16px;
            border-radius: 4px;
            font-size: 14px;
            color: #166534;
        }}
    </style>
</head>
<body>
    <div class="card">
        <span class="badge">● FastAPI Backend Online</span>
        <h1>🤖 {settings.APP_NAME}</h1>
        <p>The backend API is running successfully. To chat with the AI Companion using the conversational interface, open the Streamlit web app:</p>
        <div class="actions">
            <a class="btn" href="http://{settings.STREAMLIT_HOST}:{settings.STREAMLIT_PORT}" target="_blank">Open Chatbot Web UI (Port {settings.STREAMLIT_PORT})</a>
            <a class="btn btn-secondary" href="/docs">View Interactive API Docs</a>
        </div>
        <div class="tip">
            💡 <strong>Note:</strong> If the Chatbot UI does not load, start the Streamlit frontend with: <code>python app.py frontend</code> or <code>python app.py run</code>.
        </div>
    </div>
</body>
</html>"""


# Register Route Modules
app.include_router(health.router)
app.include_router(chat.router)
app.include_router(conversations.router)
app.include_router(documents.router)
app.include_router(rag.router)
app.include_router(audio.router)
app.include_router(images.router)
app.include_router(files.router)

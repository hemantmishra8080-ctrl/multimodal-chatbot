"""Common API schemas."""
from typing import Optional, Any
from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: str = Field(..., examples=["healthy"])
    app_name: str = Field(..., examples=["Multimodal AI Companion"])
    version: str = Field("1.0.0", examples=["1.0.0"])
    database: str = Field(..., examples=["connected"])
    vector_store: str = Field(..., examples=["ready"])
    llm_provider: str = Field(..., examples=["mock"])


class ErrorResponse(BaseModel):
    detail: str = Field(..., description="Safe, client-facing error description without stack trace")
    error_code: Optional[str] = Field(None, description="Standard error code")


class StatusResponse(BaseModel):
    success: bool
    message: str

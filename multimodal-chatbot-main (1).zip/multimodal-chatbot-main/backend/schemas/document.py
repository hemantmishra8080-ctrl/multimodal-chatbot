"""Document schemas for uploads, listing, and deletion."""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class DocumentMetadataResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    filename: str
    content_hash: str
    mime_type: str
    size_bytes: int
    status: str
    created_at: datetime
    chunk_count: int = 0


class DocumentListResponse(BaseModel):
    documents: List[DocumentMetadataResponse]
    total: int


class DocumentDeleteResponse(BaseModel):
    document_id: str
    filename: str
    deleted_chunks: int
    success: bool
    message: str

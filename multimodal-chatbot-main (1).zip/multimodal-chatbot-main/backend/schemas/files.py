"""Schemas for generated files and exports."""
from typing import Optional
from pydantic import BaseModel, Field


class GeneratedFileItem(BaseModel):
    """Metadata and content for a file generated during chat."""
    file_id: str = Field(..., description="Unique file identifier")
    filename: str = Field(..., description="Target filename including extension")
    file_type: str = Field("text", description="File extension / language (e.g. py, csv, md)")
    size_bytes: int = Field(0, description="File size in bytes")
    download_url: str = Field(..., description="Backend download URL")
    content_b64: Optional[str] = Field(None, description="Base64 encoded file content for instant download")
    mime_type: str = Field("text/plain", description="MIME type for file downloads")

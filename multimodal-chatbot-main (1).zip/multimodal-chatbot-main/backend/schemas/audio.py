"""Audio request and response schemas."""
from typing import Optional
from pydantic import BaseModel, Field


class AudioSynthesizeRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=2000, description="Text to convert to spoken audio")
    voice_speed: Optional[int] = Field(175, ge=100, le=300)


class AudioSynthesizeResponse(BaseModel):
    audio_base64: str
    format: str = "wav"
    sample_rate: int = 22050


class AudioTranscriptionResponse(BaseModel):
    transcript: str
    confidence: float = 1.0

"""Chat request and response schemas."""
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from backend.schemas.files import GeneratedFileItem


class CitationItem(BaseModel):
    document_id: str
    filename: str
    page_number: Optional[int] = None
    chunk_index: int
    text_snippet: str
    score: Optional[float] = None


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=4000, description="User message text")
    conversation_id: Optional[str] = Field(None, description="Optional conversation UUID; auto-created if empty")
    modality: str = Field("text", description="Input modality: text, rag, image, audio")
    emotional_support_mode: bool = Field(False, description="Enable empathetic companion behavior mode")
    image_base64: Optional[str] = Field(None, description="Optional base64-encoded image data for vision analysis")
    use_rag: bool = Field(False, description="Whether to query the document vector store")
    rag_document_id: Optional[str] = Field(None, description="Limit RAG scope to a specific document ID")
    llm_provider: Optional[str] = Field(None, description="Optional LLM provider: mock, gemini, groq, openai, ollama")
    api_key: Optional[str] = Field(None, description="Optional runtime API key")


class ChatResponse(BaseModel):
    conversation_id: str
    message_id: str
    response: str
    role: str = "assistant"
    modality: str = "text"
    citations: List[CitationItem] = Field(default_factory=list)
    audio_base64: Optional[str] = None
    generated_files: List[GeneratedFileItem] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)

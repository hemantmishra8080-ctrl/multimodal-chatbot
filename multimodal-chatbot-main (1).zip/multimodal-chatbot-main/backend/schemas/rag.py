"""RAG query and citation schemas."""
from typing import Optional, List
from pydantic import BaseModel, Field
from backend.schemas.chat import CitationItem


class RAGQueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=1000, description="Question to answer using documents")
    document_id: Optional[str] = Field(None, description="Optional document ID to restrict search scope")
    top_k: Optional[int] = Field(3, ge=1, le=10, description="Number of document chunks to retrieve")


class RAGQueryResponse(BaseModel):
    query: str
    answer: str
    citations: List[CitationItem] = Field(default_factory=list)
    has_sufficient_context: bool = True

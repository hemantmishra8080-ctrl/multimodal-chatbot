"""Database engine, session management, and resilient connection fallback."""
import logging
from typing import Generator
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from backend.core.config import settings
from backend.core.logging_config import logger
from backend.db.base import Base
# Import models to ensure they register on Base.metadata
import backend.db.models  # noqa: F401


def create_resilient_engine():
    """
    Attempt to connect to the configured primary database (SQLite or MySQL).
    If unreachable in local development, fall back gracefully to local SQLite.
    """
    db_url = settings.DATABASE_URL
    is_sqlite = db_url.startswith("sqlite")

    try:
        engine = create_engine(
            db_url,
            pool_pre_ping=True,
            echo=False,
            connect_args={"check_same_thread": False} if is_sqlite else {"connect_timeout": 5},
        )
        # Verify connection
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info(f"Connected successfully to database: {db_url.split('@')[-1] if '@' in db_url else 'SQLite'}")
        return engine, is_sqlite
    except Exception as exc:
        logger.warning(
            f"Could not connect to configured primary database ({db_url.split('@')[-1] if '@' in db_url else db_url}): {exc}."
        )
        logger.info(f"Falling back to local SQLite database at: {settings.SQLITE_FALLBACK_URL}")
        fallback_engine = create_engine(
            settings.SQLITE_FALLBACK_URL,
            pool_pre_ping=True,
            connect_args={"check_same_thread": False},
        )
        return fallback_engine, True


engine, IS_FALLBACK_DB = create_resilient_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db() -> None:
    """Create all database tables if they do not exist."""
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables initialized successfully.")


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency for obtaining a managed database session."""
    db: Session = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

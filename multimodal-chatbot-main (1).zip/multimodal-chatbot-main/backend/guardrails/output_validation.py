"""Output validation and sanitization guardrails."""
import re
from typing import Tuple
from backend.core.logging_config import REDACTION_PATTERNS


class OutputGuardrail:
    """Sanitizes outgoing LLM text responses to prevent secret leakage or raw script injection."""

    @staticmethod
    def sanitize_response(text: str) -> str:
        """
        Sanitize response text:
        1. Scrub any accidental leakage of API keys, tokens, or connection strings.
        2. Neutralize dangerous HTML tags (e.g., <script>, <iframe>, <object>) while preserving markdown.
        """
        if not text:
            return ""

        sanitized = text

        # 1. Apply redaction patterns for API keys and tokens
        for pattern, repl in REDACTION_PATTERNS:
            sanitized = pattern.sub(repl, sanitized)

        # 2. Neutralize dangerous raw HTML elements
        dangerous_tags = [r"<\s*script[^>]*>.*?<\s*/\s*script\s*>", r"<\s*iframe[^>]*>.*?<\s*/\s*iframe\s*>", r"<\s*object[^>]*>.*?<\s*/\s*object\s*>"]
        for dt in dangerous_tags:
            sanitized = re.sub(dt, "[UNSAFE_CONTENT_REMOVED]", sanitized, flags=re.IGNORECASE | re.DOTALL)

        return sanitized

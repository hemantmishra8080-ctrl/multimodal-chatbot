"""Safety guardrails: crisis intervention, mental health boundaries, and self-harm detection."""
import re
from typing import Tuple, Optional


# Critical crisis keywords and phrases
CRISIS_PATTERNS = [
    re.compile(r"\b(kill|end)\s+(my\s*self|my\s+life)\b", re.IGNORECASE),
    re.compile(r"\b(commit|attempt)\s+suicide\b", re.IGNORECASE),
    re.compile(r"\b(want\s+to|going\s+to)\s+die\b", re.IGNORECASE),
    re.compile(r"\b(cut|hurt|harm)\s+my\s*self\b", re.IGNORECASE),
    re.compile(r"\bno\s+reason\s+to\s+live\b", re.IGNORECASE),
    re.compile(r"\bdon'?t\s+want\s+to\s+be\s+here\s+anymore\b", re.IGNORECASE),
    re.compile(r"\boverdose\s+on\b", re.IGNORECASE),
    re.compile(r"\btake\s+all\s+(my\s+)?pills\b", re.IGNORECASE),
]

# Standard Crisis Support Response
CRISIS_RESPONSE = (
    "I hear how much pain you're carrying right now, and I care very deeply about your safety. "
    "Please know that you do not have to walk through this alone, and there is immediate, compassionate support available for you.\n\n"
    "**Immediate Support Resources (Free & Confidential, 24/7):**\n"
    "- **National Suicide and Crisis Lifeline**: Call or text **988** (available in the US and Canada).\n"
    "- **Crisis Text Line**: Text **HOME** to **741741** to connect with a crisis counselor.\n"
    "- **International Resources**: If you are outside the US/Canada, please visit **https://findahelpline.com** or call your local emergency services (such as 112 or 911).\n\n"
    "Can you reach out to someone you trust right now—a friend, family member, or professional who can be with you? "
    "Please take things one breath at a time and connect with someone who can support you right now."
)

# Medical / Prescriptive boundary patterns
MEDICAL_ADVICE_PATTERNS = [
    re.compile(r"\b(should\s+i\s+stop\s+taking|should\s+i\s+change\s+my\s+dose|diagnose\s+me)\b", re.IGNORECASE),
]


class SafetyGuardrail:
    """Evaluates emotional safety, crisis indicators, and ethical boundaries."""

    @staticmethod
    def detect_crisis(message: str) -> bool:
        """Check if message expresses imminent danger, self-harm, or suicidal ideation."""
        for pattern in CRISIS_PATTERNS:
            if pattern.search(message):
                return True
        return False

    @staticmethod
    def get_crisis_response() -> str:
        """Return deterministic, compassionate crisis intervention message."""
        return CRISIS_RESPONSE

    @staticmethod
    def check_medical_disclaimer_needed(message: str) -> bool:
        """Check if message is asking for clinical diagnosis or medication alterations."""
        for pattern in MEDICAL_ADVICE_PATTERNS:
            if pattern.search(message):
                return True
        return False

    @staticmethod
    def get_medical_disclaimer() -> str:
        """Return ethical medical disclaimer."""
        return (
            "\n\n*Reminder: I am an AI companion, not a medical doctor or licensed mental health professional. "
            "Please consult your physician or healthcare provider before making any changes to your medications or treatment plan.*"
        )

"""Input validation guardrails: message length, file size, signatures, paths."""
from typing import Tuple, Optional
from backend.core.config import settings
from backend.core.security import validate_file_signature, sanitize_filename


class InputGuardrail:
    """Validates user text and file uploads before downstream processing."""

    @staticmethod
    def validate_text_message(message: str) -> Tuple[bool, Optional[str]]:
        """Validate text message length and content."""
        if not message or not message.strip():
            return False, "Message cannot be empty or purely whitespace."

        if len(message) > settings.MAX_MESSAGE_LENGTH:
            return False, f"Message exceeds maximum allowed length of {settings.MAX_MESSAGE_LENGTH} characters (received {len(message)})."

        return True, None

    @staticmethod
    def validate_file(content: bytes, filename: str, declared_mime: str) -> Tuple[bool, Optional[str]]:
        """Validate uploaded file size, name, and magic byte signature."""
        if not content:
            return False, "Uploaded file is empty (0 bytes)."

        max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
        if len(content) > max_bytes:
            return False, f"File exceeds maximum allowed size of {settings.MAX_UPLOAD_SIZE_MB}MB (size: {len(content) / (1024*1024):.2f}MB)."

        clean_name = sanitize_filename(filename)
        if not clean_name:
            return False, "Filename is invalid or contains forbidden characters."

        # Validate magic byte signature against declared MIME type
        is_valid_sig, sig_err = validate_file_signature(content, declared_mime)
        if not is_valid_sig:
            return False, sig_err

        return True, None

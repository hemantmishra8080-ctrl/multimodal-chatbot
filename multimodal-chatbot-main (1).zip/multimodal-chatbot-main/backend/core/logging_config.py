"""Logging configuration with sensitive data redaction."""
import logging
import re
from typing import Optional
from backend.core.config import settings


# Regex patterns for sensitive data redaction
REDACTION_PATTERNS = [
    # API Keys & Tokens
    (re.compile(r"sk-[a-zA-Z0-9_\-]{20,}", re.IGNORECASE), "[REDACTED_API_KEY]"),
    (re.compile(r"gsk_[a-zA-Z0-9_\-]{20,}", re.IGNORECASE), "[REDACTED_API_KEY]"),
    (re.compile(r"AIzaSy[a-zA-Z0-9_\-]{30,}", re.IGNORECASE), "[REDACTED_API_KEY]"),
    (re.compile(r"Bearer\s+[a-zA-Z0-9_\-\.]{20,}", re.IGNORECASE), "Bearer [REDACTED_TOKEN]"),
    # DB URLs with passwords
    (re.compile(r"://([^:]+):([^@]+)@", re.IGNORECASE), r"://\1:******@"),
    # Email addresses
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b"), "[REDACTED_EMAIL]"),
    # Generic secret assignments like password=... or token=...
    (re.compile(r"(password|secret|token|api_key)\s*[:=]\s*['\"]?([^'\"\s,]+)['\"]?", re.IGNORECASE), r"\1=[REDACTED]"),
]


class RedactingFormatter(logging.Formatter):
    """Custom log formatter that scrubs sensitive credentials and PII."""

    def __init__(self, fmt: Optional[str] = None, datefmt: Optional[str] = None):
        super().__init__(fmt, datefmt)

    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        if settings.REDACT_SENSITIVE_DATA:
            for pattern, repl in REDACTION_PATTERNS:
                msg = pattern.sub(repl, msg)
        return msg


def setup_logging() -> logging.Logger:
    """Configure structured, privacy-aware logging across the application."""
    log_level = getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO)
    logger = logging.getLogger("companion")
    logger.setLevel(log_level)

    # Avoid adding duplicate handlers if setup_logging is called multiple times
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setLevel(log_level)
        formatter = RedactingFormatter(
            fmt="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    # Also apply redacting formatter to uvicorn/fastapi loggers
    for log_name in ["uvicorn", "uvicorn.access", "uvicorn.error", "fastapi"]:
        uv_logger = logging.getLogger(log_name)
        uv_logger.setLevel(log_level)
        for h in uv_logger.handlers:
            h.setFormatter(RedactingFormatter(
                fmt="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            ))

    return logger


logger = setup_logging()

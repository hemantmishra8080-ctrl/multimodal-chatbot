"""Security utilities: hashing, path sanitization, magic bytes detection."""
import hashlib
import os
import re
from typing import Tuple, Optional


# Supported MIME types and magic byte headers
MAGIC_SIGNATURES = {
    "application/pdf": [b"%PDF-"],
    "image/png": [b"\x89PNG\r\n\x1a\n"],
    "image/jpeg": [b"\xff\xd8\xff"],
    "audio/wav": [b"RIFF"],
    "audio/mpeg": [b"ID3", b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"],
}


def compute_sha256(data: bytes) -> str:
    """Compute deterministic SHA-256 hash for document content deduplication."""
    return hashlib.sha256(data).hexdigest()


def sanitize_filename(filename: str) -> str:
    """
    Sanitize uploaded filenames to prevent path traversal and arbitrary filesystem overwrite.
    Strips directory separators, relative path markers ('..'), and illegal characters.
    """
    if not filename:
        return "unnamed_file"

    # Extract basename only
    base = os.path.basename(filename.strip())

    # Remove dangerous characters, allow alphanumerics, underscores, dashes, dots
    clean = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", base)

    # Prevent hidden files and double dots
    clean = clean.lstrip(".")
    clean = re.sub(r"\.{2,}", ".", clean)

    if not clean:
        return "unnamed_file"

    return clean[:128]


def validate_file_signature(content: bytes, declared_mime: str) -> Tuple[bool, Optional[str]]:
    """
    Verify that the content header matches the declared MIME type.
    Rejects disguised executables or corrupt files.
    """
    if not content:
        return False, "File is empty (0 bytes)."

    # Text files are validated by decoding UTF-8
    if declared_mime == "text/plain":
        try:
            content[:4096].decode("utf-8")
            return True, None
        except UnicodeDecodeError:
            try:
                content[:4096].decode("latin-1")
                return True, None
            except Exception:
                return False, "File content is not valid readable text."

    # Binary signatures
    expected_signatures = MAGIC_SIGNATURES.get(declared_mime)
    if not expected_signatures:
        return False, f"Unsupported MIME type: {declared_mime}"

    for sig in expected_signatures:
        if content.startswith(sig):
            return True, None

    return False, f"File signature (magic bytes) does not match declared type: {declared_mime}"

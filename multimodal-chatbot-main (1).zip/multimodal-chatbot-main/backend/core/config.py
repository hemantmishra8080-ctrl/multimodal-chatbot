"""Application configuration using Pydantic Settings."""
from pathlib import Path
from typing import List, Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # App Information
    APP_ENV: str = "development"
    APP_NAME: str = "Multimodal AI Companion"
    DEBUG: bool = True

    # Backend Network
    BACKEND_HOST: str = "127.0.0.1"
    BACKEND_PORT: int = 8000
    BACKEND_BASE_URL: str = "http://127.0.0.1:8000"

    # Frontend Network
    STREAMLIT_HOST: str = "127.0.0.1"
    STREAMLIT_PORT: int = 8501
    STREAMLIT_CORS_ORIGIN: str = "http://localhost:8501"

    # Database
    DATABASE_URL: str = "sqlite:///./storage/companion.db"
    SQLITE_FALLBACK_URL: str = "sqlite:///./storage/companion.db"

    # LLM Settings
    LLM_PROVIDER: str = "mock"  # mock | gemini | openai | groq
    LLM_MODEL: str = "mock-model"
    LLM_API_KEY: Optional[str] = None
    GEMINI_API_KEY: Optional[str] = None
    OPENAI_API_KEY: Optional[str] = None
    GROQ_API_KEY: Optional[str] = None

    # Embeddings
    EMBEDDING_PROVIDER: str = "local"  # local | openai | gemini
    EMBEDDING_MODEL: str = "local-sentence-hash"
    EMBEDDING_API_KEY: Optional[str] = None

    # Storage Paths
    STORAGE_DIR: str = "./storage"
    UPLOAD_DIR: str = "./storage/documents"
    AUDIO_CACHE_DIR: str = "./storage/audio_cache"
    GENERATED_IMAGES_DIR: str = "./storage/generated_images"
    GENERATED_FILES_DIR: str = "./storage/generated_files"
    VECTOR_STORE_PATH: str = "./storage/vector_store"

    # Upload & Message Limits
    MAX_UPLOAD_SIZE_MB: int = 15
    MAX_MESSAGE_LENGTH: int = 4000

    # RAG Configuration
    CHUNK_SIZE: int = 1200
    CHUNK_OVERLAP: int = 200
    RETRIEVAL_TOP_K: int = 3
    RETRIEVAL_SIMILARITY_THRESHOLD: float = 0.20

    # Logging & Privacy
    LOG_LEVEL: str = "INFO"
    REDACT_SENSITIVE_DATA: bool = True

    # Guardrails
    ENABLE_GUARDRAILS: bool = True
    MAX_REQUESTS_PER_MINUTE: int = 60

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    def ensure_directories(self) -> None:
        """Ensure all required runtime storage directories exist."""
        for d in [self.STORAGE_DIR, self.UPLOAD_DIR, self.AUDIO_CACHE_DIR, self.GENERATED_IMAGES_DIR, self.GENERATED_FILES_DIR, self.VECTOR_STORE_PATH]:
            Path(d).mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_directories()

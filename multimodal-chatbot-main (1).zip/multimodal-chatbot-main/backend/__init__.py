"""Multimodal AI Companion Backend Package."""

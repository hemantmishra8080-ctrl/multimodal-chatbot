"""Main Streamlit application — Advanced Multimodal AI Assistant."""
import os
import base64
import io
import streamlit as st
from frontend.api_client import APIClient
from frontend.components.sidebar import render_sidebar
from frontend.components.chat_box import render_chat_messages
from frontend.components.document_manager import render_document_manager

# ─── Backend URL ──────────────────────────────────────────────────────────────
BACKEND_URL = os.environ.get("BACKEND_BASE_URL", "http://127.0.0.1:8000")


def _ensure_backend_running():
    """Auto-start FastAPI backend if not reachable."""
    import urllib.request, subprocess, sys, time
    health_url = f"{BACKEND_URL}/health"
    try:
        with urllib.request.urlopen(health_url, timeout=2) as r:
            if r.status == 200:
                return True
    except Exception:
        pass
    try:
        subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "backend.main:app",
             "--host", "127.0.0.1", "--port", "8000"],
        )
        for _ in range(10):
            time.sleep(0.6)
            try:
                with urllib.request.urlopen(health_url, timeout=1) as r:
                    if r.status == 200:
                        return True
            except Exception:
                continue
    except Exception:
        pass
    return False


_ensure_backend_running()

st.set_page_config(
    page_title="Multimodal AI Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "About": "Advanced Multimodal AI Assistant — RAG · Vision · TTS · Image Gen · File Export",
    },
)

# ─── CSS ──────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
.stChatMessage { border-radius: 12px; }
.block-container  { padding-top: 1.2rem; }
.citation-card {
    background: #f0f2f6; border-left: 4px solid #4e8df5;
    padding: 8px 12px; border-radius: 6px; margin: 4px 0; font-size: 0.85rem;
}
.file-pill {
    display:inline-block; background:#e8f4fd; border:1px solid #90c0e8;
    border-radius:20px; padding:3px 10px; font-size:0.8rem; margin:2px 3px;
}
</style>
""", unsafe_allow_html=True)

# ─── API Client ───────────────────────────────────────────────────────────────
api_client = APIClient(base_url=BACKEND_URL, timeout=60.0)

# ─── Session State ────────────────────────────────────────────────────────────
_defaults = {
    "messages": [],
    "active_conversation_id": None,
    "emotional_support_mode": False,
    "use_rag": False,
    "enable_tts": False,
    "rag_document_id": None,
    "image_b64": None,
    "image_filename": None,
    "selected_llm_provider": "mock",
    "user_api_key": "",
    "last_backend_error": None,
    "audio_transcript": None,   # stores transcribed voice text
}
for k, v in _defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ─── Helpers ──────────────────────────────────────────────────────────────────
def _mode_label() -> str:
    if st.session_state.get("emotional_support_mode"):
        return "💚 Emotional Support"
    if st.session_state.get("use_rag"):
        return "📚 RAG Document Mode"
    if st.session_state.get("image_b64"):
        return "🖼️ Vision Analysis"
    return "💬 General Chat"


def _backend_ok() -> bool:
    is_healthy, health_data = api_client.check_health()
    if not is_healthy:
        st.error(
            f"⚠️ **Backend Offline** — Cannot reach `{BACKEND_URL}`. "
            "Start it with:\n\n```powershell\npython app.py run\n```",
            icon="🔌",
        )
        return False
    return True


# ─── Export Chat ──────────────────────────────────────────────────────────────
def _export_chat_md() -> str:
    """Render entire session messages as a Markdown document."""
    lines = ["# AI Assistant — Chat Export\n"]
    for m in st.session_state["messages"]:
        role = "**You**" if m.get("role") == "user" else "**Assistant**"
        lines.append(f"\n---\n{role}:\n\n{m.get('content', '')}\n")
    return "\n".join(lines)


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    render_sidebar(api_client)

    st.title("🤖 Multimodal AI Assistant")

    # Active-mode banners
    if st.session_state.get("emotional_support_mode"):
        st.info(
            "💚 **Emotional Support Mode Active** — I'm here to listen with warmth and patience.",
            icon="🌿",
        )
    elif st.session_state.get("use_rag"):
        st.info(
            "📚 **Document RAG Mode Active** — Answers grounded in your uploaded documents.",
            icon="📖",
        )

    if not _backend_ok():
        st.stop()

    # Document manager (expandable)
    render_document_manager(api_client)

    # ── PILLAR 2: Image Attachment (Vision) ───────────────────────────────────
    with st.expander(
        "🖼️ Attach Image for Vision Analysis  |  🎨 Type *'generate an image of...'* to create one",
        expanded=bool(st.session_state.get("image_b64")),
    ):
        col_up, col_prev = st.columns([2, 1])
        with col_up:
            uploaded_img = st.file_uploader(
                "Upload PNG / JPG",
                type=["png", "jpg", "jpeg", "webp"],
                key="chat_image_uploader",
                help="Upload an image and ask questions about it.",
            )
            if uploaded_img is not None:
                img_bytes = uploaded_img.getvalue()
                st.session_state["image_b64"] = base64.b64encode(img_bytes).decode("utf-8")
                st.session_state["image_filename"] = uploaded_img.name
            if st.session_state.get("image_b64") and st.button("🗑️ Remove image", type="secondary"):
                st.session_state["image_b64"] = None
                st.session_state["image_filename"] = None
                st.rerun()
        with col_prev:
            if st.session_state.get("image_b64"):
                st.image(
                    base64.b64decode(st.session_state["image_b64"]),
                    caption=st.session_state.get("image_filename", "Attached"),
                    width=200,
                )
        st.info(
            "📎 **Vision**: Upload an image, then type your question.\n\n"
            "🎨 **Image Gen**: Type *'generate an image of a sunset'* — no API key needed!",
            icon="💡",
        )

    # ── PILLAR 4: Audio Input (Speech-to-Text) ────────────────────────────────
    with st.expander("🎙️ Voice Input (Speak your message)", expanded=False):
        st.caption("Record audio and the assistant will transcribe + answer it.")
        audio_input = st.audio_input("🎙️ Click to record", key="voice_recorder")
        if audio_input is not None:
            audio_bytes = audio_input.getvalue()
            if audio_bytes and len(audio_bytes) > 500:
                with st.spinner("🎧 Transcribing audio…"):
                    ok, transcript = api_client.transcribe_audio(
                        audio_bytes=audio_bytes,
                        filename="voice_input.wav",
                        mime_type="audio/wav",
                    )
                if ok and transcript and not transcript.startswith("["):
                    st.session_state["audio_transcript"] = transcript
                    st.success(f"📝 Transcribed: *{transcript}*")
                else:
                    # Use the simulated transcript text as the query anyway
                    if isinstance(transcript, str) and len(transcript) > 10:
                        # Strip brackets from fallback
                        clean = transcript.strip("[]").strip()
                        # Try to extract the spoken query portion after "Spoken query:"
                        if "Spoken query:" in clean:
                            clean = clean.split("Spoken query:")[-1].strip()
                        st.session_state["audio_transcript"] = clean
                        st.info(f"🔊 Audio received. Using: *{clean}*")
                    else:
                        st.warning("Could not transcribe audio clearly. Please type your message.")
        if st.session_state.get("audio_transcript"):
            col_use, col_clear = st.columns([3, 1])
            with col_use:
                st.info(f"📨 Ready to send: *{st.session_state['audio_transcript']}*")
            with col_clear:
                if st.button("❌ Clear", key="clear_transcript"):
                    st.session_state["audio_transcript"] = None
                    st.rerun()

    # ── Chat Export ───────────────────────────────────────────────────────────
    if st.session_state["messages"]:
        with st.expander("📥 Export Chat History", expanded=False):
            export_md = _export_chat_md()
            st.download_button(
                label="⬇️ Download as Markdown",
                data=export_md.encode("utf-8"),
                file_name="chat_export.md",
                mime="text/markdown",
                use_container_width=True,
            )

    st.divider()

    # ── Chat History ──────────────────────────────────────────────────────────
    render_chat_messages(st.session_state["messages"])

    # ── Chat Input ────────────────────────────────────────────────────────────
    if st.session_state.get("image_b64"):
        placeholder = "Describe the image or ask a question about it…"
    elif st.session_state.get("use_rag"):
        placeholder = "Ask a question about your uploaded documents…"
    elif st.session_state.get("audio_transcript"):
        placeholder = "Edit transcribed text or press Enter to send…"
    else:
        placeholder = "Type your message… (or use 🎙️ Voice Input above)"

    # Pre-fill from voice transcript
    prefill = st.session_state.pop("audio_transcript", None) or ""

    user_prompt = st.chat_input(placeholder)

    # Use voice transcript as prompt if chat_input is empty
    effective_prompt = user_prompt or (prefill if prefill else None)

    if effective_prompt:
        # Clear any stale transcript
        st.session_state["audio_transcript"] = None

        # Snapshot attachments at send-time
        image_b64_snap = st.session_state.get("image_b64")
        has_image = bool(image_b64_snap)
        modality = "image" if has_image else ("rag" if st.session_state.get("use_rag") else "text")

        # Record user message
        st.session_state["messages"].append({
            "role": "user",
            "content": effective_prompt,
            "modality": modality,
            "image_filename": st.session_state.get("image_filename") if has_image else None,
        })

        with st.chat_message("user"):
            st.markdown(effective_prompt)
            if has_image and st.session_state.get("image_filename"):
                st.caption(f"📎 Attached: {st.session_state.get('image_filename')}")

        # ── Backend call ──────────────────────────────────────────────────────
        with st.chat_message("assistant"):
            with st.spinner("Thinking…"):
                success, response_data = api_client.send_chat(
                    message=effective_prompt,
                    conversation_id=st.session_state.get("active_conversation_id"),
                    emotional_support_mode=st.session_state.get("emotional_support_mode", False),
                    use_rag=st.session_state.get("use_rag", False),
                    rag_document_id=st.session_state.get("rag_document_id"),
                    image_base64=image_b64_snap,
                    modality=modality,
                    llm_provider=st.session_state.get("selected_llm_provider"),
                    api_key=st.session_state.get("user_api_key"),
                )

            if success:
                assistant_text = response_data.get("response", "")
                citations = response_data.get("citations", [])
                resp_modality = response_data.get("modality", "text")
                resp_meta = response_data.get("metadata", {})
                resp_files = response_data.get("generated_files", [])
                st.session_state["active_conversation_id"] = response_data.get("conversation_id")

                # ── Render response ───────────────────────────────────────────
                if resp_modality == "image_generation":
                    # Show text + image inline
                    st.markdown(assistant_text)
                    img_b64 = resp_meta.get("image_base64")
                    img_url = resp_meta.get("image_url")
                    if img_b64:
                        try:
                            st.image(
                                base64.b64decode(img_b64),
                                caption=f"🎨 {resp_meta.get('image_prompt', '')}",
                                use_container_width=True,
                            )
                        except Exception:
                            if img_url:
                                st.image(img_url, caption=f"🎨 {resp_meta.get('image_prompt', '')}", use_container_width=True)
                    elif img_url:
                        st.image(img_url, caption=f"🎨 {resp_meta.get('image_prompt', '')}", use_container_width=True)
                else:
                    st.markdown(assistant_text)

                # ── PILLAR 3: Download buttons for generated files ─────────────
                if resp_files:
                    from frontend.components.chat_box import render_generated_files
                    render_generated_files(resp_files)

                # ── Citations ─────────────────────────────────────────────────
                if citations:
                    from frontend.components.chat_box import render_citations
                    render_citations(citations)

                # ── PILLAR 4: Audio playback ───────────────────────────────────
                audio_b64 = response_data.get("audio_base64")
                if not audio_b64 and st.session_state.get("enable_tts") and assistant_text:
                    with st.spinner("🔊 Synthesizing speech…"):
                        audio_b64 = api_client.synthesize_speech(assistant_text)
                if audio_b64:
                    from frontend.components.chat_box import render_audio_player
                    render_audio_player(audio_b64)

                # Store in session state for history
                st.session_state["messages"].append({
                    "role": "assistant",
                    "content": assistant_text,
                    "modality": resp_modality,
                    "citations": citations,
                    "audio_base64": audio_b64,
                    "metadata": resp_meta,
                    "generated_files": resp_files,
                })

                # Clear attached image after send
                st.session_state["image_b64"] = None
                st.session_state["image_filename"] = None
                st.rerun()

            else:
                err_msg = response_data.get("error", "Failed to reach AI assistant.")
                st.session_state["last_backend_error"] = err_msg
                st.error(f"⚠️ {err_msg}", icon="🚨")
                st.info(
                    "**Troubleshooting:**\n"
                    "- Verify your API key in the sidebar (for Gemini/Groq/OpenAI)\n"
                    "- Switch to **Local Smart Assistant** for offline mode\n"
                    "- Run `python app.py run` to start both servers",
                )


if __name__ == "__main__":
    main()

"""Document manager component for uploading and managing RAG knowledge base."""
import streamlit as st
from frontend.api_client import APIClient


def render_document_manager(api_client: APIClient):
    """Render document upload and management interface."""
    with st.expander("📁 Document Knowledge Base (Upload & Manage)", expanded=False):
        col_up, col_info = st.columns([2, 1])

        with col_up:
            uploaded_file = st.file_uploader(
                "Upload Document (PDF or TXT, max 15MB)",
                type=["pdf", "txt"],
                key="rag_doc_uploader",
                help="Uploaded files will be parsed, chunked, and indexed into the local vector store.",
            )

            if uploaded_file is not None:
                if st.button("📥 Index Document", use_container_width=True):
                    with st.spinner("Extracting text, chunking, and computing embeddings..."):
                        content = uploaded_file.getvalue()
                        filename = uploaded_file.name
                        mime_type = "application/pdf" if filename.lower().endswith(".pdf") else "text/plain"

                        success, resp = api_client.upload_document(content, filename, mime_type)
                        if success:
                            st.success(f"Successfully indexed '{filename}' ({resp.get('chunk_count', 0)} chunks).")
                            st.rerun()
                        else:
                            st.error(f"Upload failed: {resp.get('error', 'Unknown error')}")

        with col_info:
            st.markdown(
                """
                **RAG Guidelines:**
                - Files are deduplicated via SHA-256.
                - Documents are treated as untrusted data.
                - Citations will appear automatically when RAG mode is enabled.
                """
            )

        st.divider()

        # Display Document Inventory
        st.subheader("Indexed Documents")
        docs = api_client.list_documents()

        if not docs:
            st.info("No documents uploaded yet. Upload a PDF or TXT above to test RAG retrieval.")
        else:
            for d in docs:
                col_name, col_meta, col_act = st.columns([3, 2, 1])
                with col_name:
                    st.write(f"📄 **{d['filename']}**")
                with col_meta:
                    size_kb = d['size_bytes'] / 1024
                    st.caption(f"{size_kb:.1f} KB • {d['chunk_count']} chunks • {d['status']}")
                with col_act:
                    if st.button("🗑️ Delete", key=f"del_doc_{d['id']}", help="Delete document and vector index"):
                        if api_client.delete_document(d['id']):
                            st.success(f"Deleted {d['filename']}")
                            st.rerun()
                        else:
                            st.error("Deletion failed.")

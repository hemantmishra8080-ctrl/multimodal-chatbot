"""Sidebar component: conversations, model selector, modes, and safety disclaimer."""
import streamlit as st
from typing import List, Dict, Any, Optional
from frontend.api_client import APIClient


def render_sidebar(api_client: APIClient):
    """Render the full sidebar."""
    with st.sidebar:
        st.title("🤖 AI Assistant")
        st.caption("Multimodal · RAG · Vision · TTS · Image Gen")

        # ── Backend health ────────────────────────────────────────────────────
        is_healthy, health_data = api_client.check_health()
        if is_healthy:
            provider_label = health_data.get("llm_provider", "local")
            st.success(f"● Backend Connected ({provider_label} mode)", icon="✅")
        else:
            st.warning("● Backend Offline — run `python app.py run`", icon="⚠️")

        st.divider()

        # ── Conversation Management ───────────────────────────────────────────
        st.subheader("💬 Conversations")
        conversations = api_client.list_conversations()

        col_new, col_del = st.columns([3, 1])
        with col_new:
            if st.button("➕ New Chat", use_container_width=True):
                new_conv = api_client.create_conversation("New Conversation")
                if new_conv:
                    st.session_state["active_conversation_id"] = new_conv["id"]
                    st.session_state["messages"] = []
                    st.rerun()

        conv_options = {c["id"]: c.get("title", "Untitled") for c in conversations}
        current_id = st.session_state.get("active_conversation_id")

        if conv_options:
            safe_index = 0
            keys = list(conv_options.keys())
            if current_id in keys:
                safe_index = keys.index(current_id)

            selected_id = st.selectbox(
                "Select Conversation",
                options=keys,
                format_func=lambda x: conv_options.get(x, x),
                index=safe_index,
                label_visibility="collapsed",
            )

            if selected_id != current_id:
                st.session_state["active_conversation_id"] = selected_id
                detail = api_client.get_conversation(selected_id)
                if detail:
                    st.session_state["messages"] = [
                        {
                            "role": m["role"],
                            "content": m["content"],
                            "modality": m.get("modality", "text"),
                            "citations": (
                                m.get("metadata_json", {}).get("citations", [])
                                if isinstance(m.get("metadata_json"), dict) else []
                            ),
                            "metadata": m.get("metadata_json", {}) if isinstance(m.get("metadata_json"), dict) else {},
                            "generated_files": (
                                m.get("metadata_json", {}).get("generated_files", [])
                                if isinstance(m.get("metadata_json"), dict) else []
                            ),
                        }
                        for m in detail.get("messages", [])
                    ]
                st.rerun()

            with col_del:
                if current_id and st.button("🗑️", help="Delete conversation", key="del_conv"):
                    if api_client.delete_conversation(current_id):
                        st.session_state["active_conversation_id"] = None
                        st.session_state["messages"] = []
                        st.rerun()
        else:
            st.caption("No saved conversations yet.")

        st.divider()

        # ── AI Model Provider ─────────────────────────────────────────────────
        st.subheader("⚙️ Settings")
        with st.expander("🤖 AI Model Provider", expanded=False):
            prov_options = [
                "Local Smart Assistant (Offline / Test)",
                "Google Gemini (Free API)",
                "Groq — LLaMA 3.3 (Free & Fast)",
                "OpenAI — GPT-4o mini",
                "Ollama (Local LLM)",
            ]
            current_choice = st.selectbox(
                "Provider",
                options=prov_options,
                index=0,
                key="sidebar_provider_dropdown",
            )
            provider_map = {
                "Local Smart Assistant (Offline / Test)": "mock",
                "Google Gemini (Free API)": "gemini",
                "Groq — LLaMA 3.3 (Free & Fast)": "groq",
                "OpenAI — GPT-4o mini": "openai",
                "Ollama (Local LLM)": "ollama",
            }
            st.session_state["selected_llm_provider"] = provider_map.get(current_choice, "mock")

            if current_choice == "Google Gemini (Free API)":
                st.session_state["user_api_key"] = st.text_input(
                    "Gemini API Key", type="password",
                    value=st.session_state.get("user_api_key", ""),
                    placeholder="AIzaSy...",
                    help="Free key at https://aistudio.google.com/",
                )
                if st.session_state.get("user_api_key"):
                    st.success("✓ Gemini key set", icon="🔑")
                else:
                    st.info("No key — will use local mode")

            elif current_choice == "Groq — LLaMA 3.3 (Free & Fast)":
                st.session_state["user_api_key"] = st.text_input(
                    "Groq API Key", type="password",
                    value=st.session_state.get("user_api_key", ""),
                    placeholder="gsk_...",
                    help="Free key at https://console.groq.com/",
                )
                if st.session_state.get("user_api_key"):
                    st.success("✓ Groq key set", icon="🔑")

            elif current_choice == "OpenAI — GPT-4o mini":
                st.session_state["user_api_key"] = st.text_input(
                    "OpenAI API Key", type="password",
                    value=st.session_state.get("user_api_key", ""),
                    placeholder="sk-...",
                    help="Key at https://platform.openai.com/",
                )
                if st.session_state.get("user_api_key"):
                    st.success("✓ OpenAI key set", icon="🔑")

            else:
                st.session_state["user_api_key"] = ""
                if current_choice.startswith("Local"):
                    st.caption("✨ Running fully offline with smart contextual responses.")
                else:
                    st.caption("Ollama must be running locally on port 11434.")

        # ── Companion Mode Toggles ────────────────────────────────────────────
        st.session_state["emotional_support_mode"] = st.toggle(
            "💚 Emotional Support Mode",
            value=st.session_state.get("emotional_support_mode", False),
            help="Enables warm, empathetic active listening.",
        )

        st.session_state["use_rag"] = st.toggle(
            "📚 Document RAG Mode",
            value=st.session_state.get("use_rag", False),
            help="Answers grounded in your uploaded documents.",
        )

        # Document scope when RAG is on
        if st.session_state.get("use_rag"):
            docs = api_client.list_documents()
            doc_map = {"all": "All Uploaded Documents"}
            for d in docs:
                doc_map[d["id"]] = f"{d['filename']} ({d['chunk_count']} chunks)"
            selected_doc = st.selectbox(
                "Document Scope",
                options=list(doc_map.keys()),
                format_func=lambda x: doc_map[x],
                key="rag_doc_selector",
            )
            st.session_state["rag_document_id"] = None if selected_doc == "all" else selected_doc

        st.session_state["enable_tts"] = st.toggle(
            "🔊 Voice Output (TTS)",
            value=st.session_state.get("enable_tts", False),
            help="Auto-speak every assistant response using local TTS.",
        )

        st.divider()

        # ── Safety Disclaimer ─────────────────────────────────────────────────
        st.markdown(
            """
            <div style="font-size:0.78rem;color:#888;line-height:1.4;">
            <strong>Safety Notice:</strong><br>
            This AI is not a licensed therapist or emergency service.<br><br>
            In crisis? Call or text <strong>988</strong> (US/Canada)
            or visit <strong>findahelpline.com</strong>.
            </div>
            """,
            unsafe_allow_html=True,
        )

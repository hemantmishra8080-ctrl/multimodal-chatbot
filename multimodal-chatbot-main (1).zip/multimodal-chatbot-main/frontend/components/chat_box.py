"""Chat message renderer: citations, images, file downloads, and audio playback."""
import base64
import streamlit as st
from typing import List, Dict, Any


# ─── Extension → icon map ─────────────────────────────────────────────────────
_EXT_ICONS = {
    "py": "🐍", "js": "🟨", "ts": "🔷", "html": "🌐", "css": "🎨",
    "csv": "📊", "json": "📦", "md": "📝", "txt": "📄", "sh": "💻",
    "sql": "🗄️", "ino": "⚡", "cpp": "⚙️", "c": "⚙️", "java": "☕",
    "yaml": "📋", "yml": "📋", "xml": "🗂️",
}


def render_citations(citations: List[Dict[str, Any]]):
    """Render verifiable document citation cards."""
    if not citations:
        return
    with st.expander(f"📑 Source Citations ({len(citations)})", expanded=False):
        for i, c in enumerate(citations, 1):
            filename = c.get("filename", "Unknown Document")
            page = c.get("page_number")
            page_str = f"Page {page}" if page else "Whole document"
            score = c.get("score")
            score_str = f" • Match: {score * 100:.1f}%" if score is not None else ""
            snippet = c.get("text_snippet", "")
            st.markdown(f"**[{i}] {filename}** ({page_str}{score_str})")
            st.caption(f'"{snippet.strip()}..."')
            if i < len(citations):
                st.divider()


def render_generated_files(files: List[Dict[str, Any]]):
    """Render one-click download buttons for every generated script / data file."""
    if not files:
        return

    st.markdown("##### 📁 Generated Files — Click to Download")
    # At most 3 columns
    n_cols = min(len(files), 3)
    cols = st.columns(n_cols)
    for idx, f_item in enumerate(files):
        col = cols[idx % n_cols]
        fname = f_item.get("filename", f"file_{idx + 1}")
        ftype = f_item.get("file_type", "txt")
        icon = _EXT_ICONS.get(ftype, "📄")
        size_b = f_item.get("size_bytes", 0)
        size_str = f"{size_b / 1024:.1f} KB" if size_b > 1024 else f"{size_b} B"
        b64_data = f_item.get("content_b64")

        if b64_data:
            try:
                raw_bytes = base64.b64decode(b64_data)
                col.download_button(
                    label=f"{icon} {fname}  ({size_str})",
                    data=raw_bytes,
                    file_name=fname,
                    mime=f_item.get("mime_type", "application/octet-stream"),
                    key=f"dl_{f_item.get('file_id', idx)}_{idx}",
                    help=f"Download {fname}",
                    use_container_width=True,
                )
            except Exception:
                col.caption(f"{icon} {fname}  ({size_str})")
        else:
            # Show a link if no base64 is available (backend URL)
            dl_url = f_item.get("download_url", "")
            col.markdown(f"{icon} [{fname}]({dl_url})  ({size_str})")


def render_audio_player(audio_base64: str):
    """Render an inline WAV audio player from a base64 string."""
    if not audio_base64:
        return
    try:
        audio_bytes = base64.b64decode(audio_base64)
        st.audio(audio_bytes, format="audio/wav")
    except Exception:
        pass


def render_chat_messages(messages: List[Dict[str, Any]]):
    """Render all conversation bubbles in order."""
    for msg in messages:
        role = msg.get("role", "assistant")
        content = msg.get("content", "")
        citations = msg.get("citations", [])
        audio_b64 = msg.get("audio_base64")
        modality = msg.get("modality", "text")
        metadata = msg.get("metadata", {})
        gen_files = msg.get("generated_files", [])

        with st.chat_message(role):
            # Render main text
            st.markdown(content)

            # Render generated image for image_generation modality
            if modality == "image_generation":
                img_b64 = metadata.get("image_base64")
                img_url = metadata.get("image_url")
                caption = f"🎨 {metadata.get('image_prompt', '')}"
                if img_b64:
                    try:
                        st.image(base64.b64decode(img_b64), caption=caption, use_container_width=True)
                    except Exception:
                        if img_url:
                            st.image(img_url, caption=caption, use_container_width=True)
                elif img_url:
                    st.image(img_url, caption=caption, use_container_width=True)

            # File download buttons
            if gen_files:
                render_generated_files(gen_files)

            # Citations
            if citations:
                render_citations(citations)

            # Audio playback
            if audio_b64:
                render_audio_player(audio_b64)

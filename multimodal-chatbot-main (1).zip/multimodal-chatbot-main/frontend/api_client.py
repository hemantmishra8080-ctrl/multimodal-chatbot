"""HTTP API Client — Streamlit frontend ↔ FastAPI backend."""
import httpx
from typing import Optional, List, Dict, Any, Tuple


class APIClient:
    """Encapsulates all REST communication with the FastAPI backend."""

    def __init__(self, base_url: str = "http://127.0.0.1:8000", timeout: float = 60.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # ── Health ────────────────────────────────────────────────────────────────

    def check_health(self) -> Tuple[bool, Dict[str, Any]]:
        try:
            with httpx.Client(timeout=5.0) as client:
                res = client.get(f"{self.base_url}/health")
                if res.status_code == 200:
                    return True, res.json()
                return False, {"error": f"Status {res.status_code}"}
        except Exception:
            return False, {"error": f"Cannot reach {self.base_url}"}

    # ── Conversations ──────────────────────────────────────────────────────────

    def list_conversations(self) -> List[Dict[str, Any]]:
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.get(f"{self.base_url}/api/v1/conversations")
                if res.status_code == 200:
                    return res.json()
        except Exception:
            pass
        return []

    def create_conversation(self, title: str = "New Conversation") -> Optional[Dict[str, Any]]:
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.post(f"{self.base_url}/api/v1/conversations", json={"title": title})
                if res.status_code == 201:
                    return res.json()
        except Exception:
            pass
        return None

    def get_conversation(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.get(f"{self.base_url}/api/v1/conversations/{conversation_id}")
                if res.status_code == 200:
                    return res.json()
        except Exception:
            pass
        return None

    def delete_conversation(self, conversation_id: str) -> bool:
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.delete(f"{self.base_url}/api/v1/conversations/{conversation_id}")
                return res.status_code == 200
        except Exception:
            return False

    # ── Chat ──────────────────────────────────────────────────────────────────

    def send_chat(
        self,
        message: str,
        conversation_id: Optional[str] = None,
        emotional_support_mode: bool = False,
        use_rag: bool = False,
        rag_document_id: Optional[str] = None,
        image_base64: Optional[str] = None,
        modality: str = "text",
        llm_provider: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> Tuple[bool, Dict[str, Any]]:
        """Submit a message to the /api/v1/chat endpoint."""
        payload = {
            "message": message,
            "conversation_id": conversation_id,
            "emotional_support_mode": emotional_support_mode,
            "use_rag": use_rag,
            "rag_document_id": rag_document_id,
            "image_base64": image_base64,
            "modality": modality,
            "llm_provider": llm_provider or "mock",
            "api_key": api_key or None,
        }
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.post(f"{self.base_url}/api/v1/chat", json=payload)
                if res.status_code == 200:
                    return True, res.json()
                # Try to extract detail from JSON error body
                try:
                    detail = res.json().get("detail", f"Server returned {res.status_code}")
                except Exception:
                    detail = res.text or f"Server returned {res.status_code}"
                return False, {"error": detail}
        except httpx.ConnectError:
            return False, {"error": "Backend is unreachable. Please ensure FastAPI is running."}
        except httpx.TimeoutException:
            return False, {"error": "Request timed out. The AI is taking too long — try again."}
        except Exception as exc:
            return False, {"error": f"Network error: {exc}"}

    # ── Documents ──────────────────────────────────────────────────────────────

    def upload_document(self, file_bytes: bytes, filename: str, mime_type: str) -> Tuple[bool, Dict[str, Any]]:
        try:
            files = {"file": (filename, file_bytes, mime_type)}
            with httpx.Client(timeout=self.timeout) as client:
                res = client.post(f"{self.base_url}/api/v1/documents", files=files)
                if res.status_code in (200, 201):
                    return True, res.json()
                try:
                    detail = res.json().get("detail", "Upload failed")
                except Exception:
                    detail = res.text
                return False, {"error": detail}
        except Exception as exc:
            return False, {"error": f"Upload error: {exc}"}

    def list_documents(self) -> List[Dict[str, Any]]:
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.get(f"{self.base_url}/api/v1/documents")
                if res.status_code == 200:
                    return res.json().get("documents", [])
        except Exception:
            pass
        return []

    def delete_document(self, document_id: str) -> bool:
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.delete(f"{self.base_url}/api/v1/documents/{document_id}")
                return res.status_code == 200
        except Exception:
            return False

    # ── Audio ──────────────────────────────────────────────────────────────────

    def synthesize_speech(self, text: str) -> Optional[str]:
        """Convert text to spoken audio. Returns base64-encoded WAV string or None."""
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.post(
                    f"{self.base_url}/api/v1/audio/synthesize",
                    json={"text": text[:600]},
                )
                if res.status_code == 200:
                    return res.json().get("audio_base64")
        except Exception:
            pass
        return None

    def transcribe_audio(
        self,
        audio_bytes: bytes,
        filename: str = "voice.wav",
        mime_type: str = "audio/wav",
    ) -> Tuple[bool, str]:
        """Send audio to STT endpoint. Returns (success, transcript_text)."""
        try:
            files = {"file": (filename, audio_bytes, mime_type)}
            with httpx.Client(timeout=self.timeout) as client:
                res = client.post(f"{self.base_url}/api/v1/audio/transcribe", files=files)
                if res.status_code == 200:
                    return True, res.json().get("transcript", "")
                try:
                    detail = res.json().get("detail", f"Status {res.status_code}")
                except Exception:
                    detail = res.text
                return False, f"Transcription error: {detail}"
        except Exception as exc:
            return False, f"Transcription failed: {exc}"

"""Unified launcher and diagnostic CLI utility for Multimodal AI Companion."""
import os
import subprocess
import sys
import time
import urllib.request
from backend.core.config import settings


def run_backend():
    """Start the FastAPI backend with uvicorn."""
    print(f"Starting FastAPI backend on {settings.BACKEND_HOST}:{settings.BACKEND_PORT}...")
    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host=settings.BACKEND_HOST,
        port=settings.BACKEND_PORT,
        reload=settings.DEBUG,
    )


def run_frontend():
    """Start the Streamlit conversational UI."""
    print(f"Starting Streamlit frontend on {settings.STREAMLIT_HOST}:{settings.STREAMLIT_PORT}...")
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        "frontend/streamlit_app.py",
        "--server.address",
        settings.STREAMLIT_HOST,
        "--server.port",
        str(settings.STREAMLIT_PORT),
    ]
    subprocess.run(cmd)


def run_all():
    """Start both FastAPI backend and Streamlit frontend in a unified process."""
    print("=" * 65)
    print("🚀 Starting Multimodal AI Companion (Backend + Frontend)...")
    print("=" * 65)

    health_url = f"{settings.BACKEND_BASE_URL}/health"
    backend_proc = None

    # Check if backend is already running
    backend_already_running = False
    try:
        with urllib.request.urlopen(health_url, timeout=1) as resp:
            if resp.status == 200:
                backend_already_running = True
                print(f"1. FastAPI backend is already running at {settings.BACKEND_BASE_URL} ✅")
    except Exception:
        pass

    if not backend_already_running:
        backend_cmd = [
            sys.executable,
            "-m",
            "uvicorn",
            "backend.main:app",
            "--host",
            settings.BACKEND_HOST,
            "--port",
            str(settings.BACKEND_PORT),
            "--reload",
        ]
        print(f"1. Starting FastAPI backend on http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}...")
        backend_proc = subprocess.Popen(backend_cmd)

        # Wait for backend health
        print("   Waiting for backend to be ready...", end="", flush=True)
        for _ in range(30):
            try:
                with urllib.request.urlopen(health_url, timeout=1) as resp:
                    if resp.status == 200:
                        print(" Ready! ✅")
                        break
            except Exception:
                time.sleep(0.5)
                print(".", end="", flush=True)
        else:
            print("\n   Warning: Backend took longer than expected to initialize.")

    frontend_cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        "frontend/streamlit_app.py",
        "--server.address",
        settings.STREAMLIT_HOST,
        "--server.port",
        str(settings.STREAMLIT_PORT),
    ]

    print(f"2. Starting Streamlit frontend on http://{settings.STREAMLIT_HOST}:{settings.STREAMLIT_PORT}...")
    print("=" * 65)
    print(f"💬 Chatbot UI:  http://localhost:{settings.STREAMLIT_PORT}")
    print(f"📖 API Docs:    http://localhost:{settings.BACKEND_PORT}/docs")
    print("Press CTRL+C anytime in this window to stop.")
    print("=" * 65)

    try:
        subprocess.run(frontend_cmd)
    except KeyboardInterrupt:
        pass
    finally:
        if backend_proc:
            print("\nStopping backend server...")
            backend_proc.terminate()
            try:
                backend_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                backend_proc.kill()
        print("Application stopped cleanly.")


def run_diagnostics():
    """Check configuration and connectivity."""
    print("=" * 60)
    print("Multimodal AI Companion - Environment Diagnostic Check")
    print("=" * 60)
    print(f"• Python executable: {sys.executable}")
    print(f"• Python version:    {sys.version.split()[0]}")
    print(f"• App Environment:   {settings.APP_ENV}")
    print(f"• Backend URL:       {settings.BACKEND_BASE_URL}")
    print(f"• Streamlit URL:     http://{settings.STREAMLIT_HOST}:{settings.STREAMLIT_PORT}")
    print(f"• Database URL:      {settings.DATABASE_URL.split('@')[-1] if '@' in settings.DATABASE_URL else settings.DATABASE_URL}")
    print(f"• LLM Provider:      {settings.LLM_PROVIDER}")
    print(f"• Embedding:         {settings.EMBEDDING_PROVIDER}")
    print(f"• Storage dir:       {settings.STORAGE_DIR}")

    # Check directories
    settings.ensure_directories()
    print("• Storage folders:   Verified & ready.")

    # Check DB
    from backend.db.session import engine, IS_FALLBACK_DB
    print(f"• Active DB Dialect: {engine.dialect.name} {'(SQLite)' if engine.dialect.name == 'sqlite' else '(MySQL)'}")
    print("=" * 60)
    print("All checks passed. System is ready to run.")


def print_usage():
    print("""
Usage: python app.py [command]

Available commands:
  run (or all) Start BOTH backend server and Streamlit frontend (Recommended)
  frontend     Start only the Streamlit user interface (port 8501)
  backend      Start only the FastAPI backend server (port 8000)
  check        Run configuration & environment diagnostics
  test         Execute test suite using pytest
""")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        run_all()
    else:
        action = sys.argv[1].lower()
        if action in ("run", "all", "start"):
            run_all()
        elif action == "backend":
            run_backend()
        elif action == "frontend":
            run_frontend()
        elif action == "check":
            run_diagnostics()
        elif action == "test":
            subprocess.run([sys.executable, "-m", "pytest", "tests/", "-v"])
        elif action in ("help", "-h", "--help"):
            print_usage()
        else:
            print(f"Unknown command: {action}")
            print_usage()

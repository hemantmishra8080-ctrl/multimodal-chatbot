"""Conversation and message persistence test suite."""
from fastapi.testclient import TestClient


def test_conversation_lifecycle(client: TestClient):
    """Test full CRUD lifecycle of conversations and associated messages."""
    # 1. Create a conversation
    create_res = client.post("/api/v1/conversations", json={"title": "Test Thread"})
    assert create_res.status_code == 201
    conv_data = create_res.json()
    conv_id = conv_data["id"]
    assert conv_data["title"] == "Test Thread"

    # 2. List conversations
    list_res = client.get("/api/v1/conversations")
    assert list_res.status_code == 200
    conv_ids = [c["id"] for c in list_res.json()]
    assert conv_id in conv_ids

    # 3. Post a message to this conversation
    chat_res = client.post(
        "/api/v1/chat",
        json={
            "conversation_id": conv_id,
            "message": "Hello, companion!",
            "modality": "text",
        },
    )
    assert chat_res.status_code == 200
    chat_data = chat_res.json()
    assert chat_data["conversation_id"] == conv_id
    assert len(chat_data["response"]) > 0

    # 4. Retrieve conversation messages
    detail_res = client.get(f"/api/v1/conversations/{conv_id}")
    assert detail_res.status_code == 200
    detail_data = detail_res.json()
    assert len(detail_data["messages"]) == 2  # 1 user + 1 assistant
    assert detail_data["messages"][0]["role"] == "user"
    assert detail_data["messages"][0]["content"] == "Hello, companion!"
    assert detail_data["messages"][1]["role"] == "assistant"

    # 5. Delete conversation
    del_res = client.delete(f"/api/v1/conversations/{conv_id}")
    assert del_res.status_code == 200
    assert del_res.json()["success"] is True

    # 6. Verify 404 after deletion
    get_again = client.get(f"/api/v1/conversations/{conv_id}")
    assert get_again.status_code == 404

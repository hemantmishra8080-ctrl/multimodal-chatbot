"""Automated test suite package."""

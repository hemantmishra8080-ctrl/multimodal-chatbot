"""Health endpoint test suite."""
from fastapi.testclient import TestClient


def test_health_endpoint(client: TestClient):
    """Verify health endpoint returns valid status without leaking secrets."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()

    assert data["status"] in ("healthy", "degraded")
    assert "app_name" in data
    assert data["version"] == "1.0.0"
    assert "database" in data
    assert "llm_provider" in data

    # Verify no credentials or private connection strings are leaked
    response_str = response.text.lower()
    assert "password" not in response_str
    assert "secret" not in response_str
    assert "root:" not in response_str

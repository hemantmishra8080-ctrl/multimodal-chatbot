"""Pytest fixtures: isolated in-memory test database, FastAPI TestClient, and clean mocks."""
import os
import pytest
from typing import Generator
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool

from backend.db.base import Base
import backend.db.models  # ensure models are loaded
from backend.main import app
from backend.api.deps import get_database
from backend.core.config import settings

# Force safe settings during test runs
settings.APP_ENV = "testing"
settings.LLM_PROVIDER = "mock"
settings.EMBEDDING_PROVIDER = "local"
settings.STORAGE_DIR = "./storage/test_storage"
settings.VECTOR_STORE_PATH = "./storage/test_storage/vector_store"
settings.UPLOAD_DIR = "./storage/test_storage/documents"
settings.AUDIO_CACHE_DIR = "./storage/test_storage/audio_cache"
settings.ensure_directories()

# Isolated in-memory SQLite engine for tests
TEST_DB_URL = "sqlite:///:memory:"
test_engine = create_engine(
    TEST_DB_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)


@pytest.fixture(scope="session", autouse=True)
def setup_test_database():
    """Create all schema tables in the in-memory test database once for the session."""
    Base.metadata.create_all(bind=test_engine)
    yield
    Base.metadata.drop_all(bind=test_engine)


@pytest.fixture
def db_session() -> Generator[Session, None, None]:
    """Provide a fresh isolated transactional session for a test function."""
    connection = test_engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)

    yield session

    session.close()
    transaction.rollback()
    connection.close()


@pytest.fixture
def client(db_session: Session) -> Generator[TestClient, None, None]:
    """FastAPI TestClient with overridden database dependency."""
    def override_get_database():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_database] = override_get_database
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()

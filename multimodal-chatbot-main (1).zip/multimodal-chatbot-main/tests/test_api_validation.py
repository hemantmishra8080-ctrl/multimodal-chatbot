"""API request validation test suite."""
from fastapi.testclient import TestClient


def test_empty_chat_message(client: TestClient):
    """Verify chat endpoint rejects empty or whitespace-only messages."""
    res1 = client.post("/api/v1/chat", json={"message": ""})
    assert res1.status_code in (400, 422)

    res2 = client.post("/api/v1/chat", json={"message": "   \n\t  "})
    assert res2.status_code in (400, 422)


def test_oversized_chat_message(client: TestClient):
    """Verify chat endpoint rejects messages exceeding maximum length."""
    long_msg = "A" * 4500
    res = client.post("/api/v1/chat", json={"message": long_msg})
    assert res.status_code in (400, 422)


def test_empty_document_upload(client: TestClient):
    """Verify document upload rejects 0-byte files."""
    files = {"file": ("empty.txt", b"", "text/plain")}
    res = client.post("/api/v1/documents", files=files)
    assert res.status_code == 400
    assert "empty" in res.json().get("detail", "").lower()


def test_disguised_file_signature(client: TestClient):
    """Verify upload rejects executable or non-PDF binary disguised as PDF."""
    fake_pdf = b"MZ\x90\x00\x03\x00\x00\x00NotARealPdf"
    files = {"file": ("malicious.pdf", fake_pdf, "application/pdf")}
    res = client.post("/api/v1/documents", files=files)
    assert res.status_code == 400
    assert "signature" in res.json().get("detail", "").lower()

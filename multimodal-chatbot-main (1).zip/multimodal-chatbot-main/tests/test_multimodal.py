"""Multimodal Vision and Audio test suite."""
import io
import base64
from PIL import Image
from fastapi.testclient import TestClient


def create_sample_png_base64() -> str:
    """Generate a valid in-memory PNG image encoded in base64."""
    img = Image.new("RGB", (64, 64), color=(73, 109, 137))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def test_image_vision_chat(client: TestClient):
    """Verify image attachment processing and vision provider dispatch."""
    b64_img = create_sample_png_base64()

    res = client.post(
        "/api/v1/chat",
        json={
            "message": "What is in this image?",
            "image_base64": b64_img,
            "modality": "image",
        },
    )
    assert res.status_code == 200
    data = res.json()
    assert data["modality"] == "image"
    assert len(data["response"]) > 0


def test_corrupt_image_rejection(client: TestClient):
    """Verify invalid base64 image strings are rejected with 400 Bad Request."""
    res = client.post(
        "/api/v1/chat",
        json={
            "message": "Analyze this corrupted data",
            "image_base64": "NotAValidBase64String!!==",
            "modality": "image",
        },
    )
    assert res.status_code == 400
    assert "image" in res.json().get("detail", "").lower()


def test_audio_speech_synthesis(client: TestClient):
    """Verify speech synthesis endpoint returns valid base64 audio bytes."""
    res = client.post(
        "/api/v1/audio/synthesize",
        json={"text": "Hello, this is a test of the speech synthesis engine."},
    )
    assert res.status_code == 200
    data = res.json()
    assert "audio_base64" in data
    assert data["format"] == "wav"

    # Decode and verify WAV header
    audio_bytes = base64.b64decode(data["audio_base64"])
    assert len(audio_bytes) > 44
    assert audio_bytes.startswith(b"RIFF")


def test_audio_transcription(client: TestClient):
    """Verify speech-to-text endpoint handles audio input."""
    dummy_wav = b"RIFF" + b"\x00" * 40
    files = {"file": ("test.wav", dummy_wav, "audio/wav")}
    res = client.post("/api/v1/audio/transcribe", files=files)
    assert res.status_code == 200
    data = res.json()
    assert "transcript" in data
    assert len(data["transcript"]) > 0

# Multimodal AI Companion with RAG & Security Guardrails

A secure, modular, locally runnable MVP of a **Multimodal AI Companion** built with **FastAPI**, **Streamlit**, **SQLAlchemy 2.x**, **Alembic**, and **MySQL** (with automated local SQLite fallback for seamless zero-setup execution).

The application features document-grounded question answering (RAG) with verifiable source citations, multimodal vision and speech processing, an empathetic emotional support mode, and centralized application security guardrails.

---

## 1. System Architecture & RAG Data Flow

```mermaid
flowchart TD
    User([User / Browser]) <--> UI[Streamlit Frontend :8501]
    UI <--> |HTTPX REST API Calls| API[FastAPI Backend :8000 /api/v1]

    subgraph Security & Guardrail Layer
        API --> InputCheck[Input Validation: MIME & Size]
        InputCheck --> InjectionCheck[Prompt Injection & Jailbreak Defense]
        InjectionCheck --> SafetyCheck[Crisis & Self-Harm Interception]
        SafetyCheck -.-> RedactedLog[(Privacy-Aware Logger)]
    end

    subgraph Business Logic & Providers
        SafetyCheck --> ServiceRouter{Service Router}
        ServiceRouter --> ChatSvc[Chat Service]
        ServiceRouter --> RAGSvc[RAG Service]
        ServiceRouter --> DocSvc[Document Ingestion & Chunking]
        ServiceRouter --> EmoSvc[Emotional Support Companion]
        ServiceRouter --> MultiSvc[Vision & Audio Engine]
    end

    subgraph Storage & Adapters
        DocSvc --> VectorStore[(Local Persistent Vector Store)]
        RAGSvc <--> VectorStore
        ChatSvc <--> DB[(MySQL / Resilient SQLite DB)]
        DocSvc <--> DB
        ChatSvc --> LLMAdapter[LLM Adapter: Mock / Gemini / OpenAI]
        MultiSvc --> TTS[pyttsx3 Local TTS Engine]
    end
```

### RAG Data Flow
1. **Upload & Validation**: PDF/TXT document byte headers (magic bytes) and file sizes are strictly validated.
2. **Deduplication**: SHA-256 hash is computed. If the document has already been processed, existing metadata is reused.
3. **Text Parsing & Chunking**: `pypdf` extracts text page-by-page. Text is segmented into configurable chunks (default: 1,200 chars) with sentence-aware overlap (default: 200 chars).
4. **Vector Embedding**: Text chunks are embedded into dense vectors using the embedding adapter (offline pure-Python/NumPy feature vectorizer or cloud embeddings).
5. **Relational Metadata**: Document records and chunk references (`document_chunks`) are stored in MySQL/SQLite, linking relational IDs to vector store IDs.
6. **Context-Grounded Retrieval**: Queries are embedded, and cosine similarity matches the top-$k$ relevant chunks.
7. **Strict Context Isolation**: Retrieved text is encapsulated in `<untrusted_document_context source="..." page="...">` XML blocks with system prompts preventing instruction overrides.
8. **Citation Return**: The assistant response includes verified citation cards detailing document filename, page number, match score, and text excerpt.

---

## 2. Core Capabilities

- **Natural Language Chat**: Multi-turn conversational memory with sliding context window.
- **Document-Grounded RAG**: PDF and TXT ingestion, chunking, and verifiable citations.
- **Empathetic Emotional Support**: Dedicated mode providing active listening, grounding techniques (box breathing, 5-4-3-2-1 sensory exercise), and non-judgmental guidance.
- **Deterministic Crisis Safety**: Automatic interception of self-harm or suicidal ideation that immediately provides the **988 Suicide & Crisis Lifeline**, Crisis Text Line (**741741**), and international crisis directories.
- **Multimodal Inputs & Outputs**:
  - **Vision**: Analyzes uploaded images (PNG, JPEG) via vision provider.
  - **Voice (TTS)**: Synthesizes spoken audio WAV responses using local `pyttsx3` (zero API cost).
  - **Speech-to-Text**: Endpoint for transcribing audio inputs.
- **Centralized Security**:
  - File signature (magic bytes) validation.
  - Path traversal and malicious filename neutralization.
  - Sensitive data scrubbing in logs (API keys, passwords, bearer tokens, emails).
  - HTML tag neutralization preventing cross-site scripting (XSS).
- **Zero-Credential Startup**: Runs out of the box in `mock` provider mode without needing paid API keys.

---

## 3. Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Backend API** | FastAPI 0.115+, Uvicorn | High-performance RESTful API under `/api/v1` |
| **Frontend UI** | Streamlit 1.38+ | Interactive conversational UI |
| **Relational Database** | MySQL 8.0+ / SQLite fallback | Conversations, messages, documents, chunks, feedback |
| **ORM & Migrations** | SQLAlchemy 2.0+, Alembic 1.13+ | Schema management and database migrations |
| **HTTP Client** | HTTPX | Frontend-to-backend REST communication |
| **Data Validation** | Pydantic v2, Pydantic Settings | Strict request/response modeling and configuration |
| **Vector Index** | Local Persistent Vector Store | Cosine similarity vector search |
| **Document Extraction**| PyPDF 5.0+, Python io/re | PDF and TXT page-level text extraction |
| **Audio Processing** | pyttsx3 2.9+, wave | Local speech synthesis without cloud costs |
| **Testing** | Pytest 8.0+, FastAPI TestClient | 100% mocked automated testing suite |

---

## 4. Windows PowerShell Setup Guide

### Step 1: Open PowerShell and Navigate to Workspace
```powershell
cd C:\Users\siddh\Downloads\chatbot
```

### Step 2: (Optional) Create and Activate Virtual Environment
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Environment Configuration
Copy `.env.example` to `.env`:
```powershell
Copy-Item .env.example .env
```

*(Optional)* If you have live API keys for Google Gemini, OpenAI, or a local MySQL server, edit `.env`:
```ini
# To use MySQL:
DATABASE_URL=mysql+pymysql://root:your_password@localhost:3306/multimodal_companion

# To use Google Gemini:
LLM_PROVIDER=gemini
GEMINI_API_KEY=your_gemini_api_key_here

# To use OpenAI:
LLM_PROVIDER=openai
OPENAI_API_KEY=your_openai_api_key_here
```
> **Note**: If MySQL is not running or no API keys are provided, the application runs automatically using its built-in offline mock provider and local SQLite database (`storage/companion.db`).

### Step 5: Run Database Migrations
```powershell
python -m alembic upgrade head
```

---

## 5. Running the Application

### Option A: One-Command All-in-One Runner (Recommended)

Simply run:
```powershell
python app.py
```
*(Or double-click `run.bat` in the project folder)*

This command automatically starts both the FastAPI backend (port 8000) and the Streamlit frontend (port 8501) together, and opens the conversational UI in your browser!

### Option B: Running in Two Separate Terminals

**Terminal 1 — Start FastAPI Backend (Port 8000):**
```powershell
python app.py backend
```

**Terminal 2 — Start Streamlit Frontend (Port 8501):**
```powershell
python app.py frontend
```

### URLs
- **Chatbot Web Interface**: **http://localhost:8501**
- **FastAPI Interactive Docs**: **http://127.0.0.1:8000/docs**
- **API Health Check**: **http://127.0.0.1:8000/health**

---

## 6. Running Automated Tests

Run the complete test suite (all 19 tests run with zero external API dependencies):
```powershell
python -m pytest tests/ -v
```

Output:
```
============================= test session starts =============================
tests/test_api_validation.py::test_empty_chat_message PASSED             [  5%]
tests/test_api_validation.py::test_oversized_chat_message PASSED         [ 10%]
tests/test_api_validation.py::test_empty_document_upload PASSED          [ 15%]
tests/test_api_validation.py::test_disguised_file_signature PASSED       [ 21%]
tests/test_conversations.py::test_conversation_lifecycle PASSED          [ 26%]
tests/test_emotional_support.py::test_emotional_support_mode PASSED      [ 31%]
tests/test_emotional_support.py::test_crisis_intervention_triggers_deterministic_safety PASSED [ 36%]
tests/test_emotional_support.py::test_crisis_chat_response_intercept PASSED [ 42%]
tests/test_emotional_support.py::test_medical_advice_disclaimer PASSED   [ 47%]
tests/test_guardrails.py::test_prompt_injection_detection PASSED         [ 52%]
tests/test_guardrails.py::test_untrusted_context_encapsulation PASSED    [ 57%]
tests/test_guardrails.py::test_sensitive_data_log_redaction PASSED       [ 63%]
tests/test_guardrails.py::test_output_sanitization PASSED                [ 68%]
tests/test_health.py::test_health_endpoint PASSED                        [ 73%]
tests/test_multimodal.py::test_image_vision_chat PASSED                  [ 78%]
tests/test_multimodal.py::test_corrupt_image_rejection PASSED            [ 84%]
tests/test_multimodal.py::test_audio_speech_synthesis PASSED             [ 89%]
tests/test_multimodal.py::test_audio_transcription PASSED                [ 94%]
tests/test_rag.py::test_rag_ingest_query_and_delete PASSED               [100%]
======================= 19 passed, 2 warnings in 1.17s ========================
```

---

## 7. Example API Requests and Responses

### 1. Health Check
`GET http://127.0.0.1:8000/health`

**Response (200 OK):**
```json
{
  "status": "healthy",
  "app_name": "Multimodal AI Companion",
  "version": "1.0.0",
  "database": "connected",
  "vector_store": "ready",
  "llm_provider": "mock"
}
```

### 2. Conversational Chat
`POST http://127.0.0.1:8000/api/v1/chat`

**Request:**
```json
{
  "message": "Hello, how can you help me today?",
  "emotional_support_mode": false,
  "use_rag": false
}
```

**Response (200 OK):**
```json
{
  "conversation_id": "4b5d21e8-782a-4a58-8685-c1cfc13a0c5f",
  "message_id": "89e58e65-3850-482d-8e47-eb5419409823",
  "response": "I received your message: \"Hello, how can you help me today?\". As your multimodal AI companion, I'm here to assist you with document Q&A, conversations, and emotional support. How else can I help you today?",
  "role": "assistant",
  "modality": "text",
  "citations": [],
  "metadata": {}
}
```

### 3. Document-Grounded RAG Query
`POST http://127.0.0.1:8000/api/v1/rag/query`

**Request:**
```json
{
  "query": "What database does the companion use?",
  "top_k": 3
}
```

**Response (200 OK):**
```json
{
  "query": "What database does the companion use?",
  "answer": "Based on the provided reference document, here is the information answering your question: The system uses MySQL with SQLAlchemy 2.0 and Alembic for persistence...",
  "citations": [
    {
      "document_id": "a9bf660c-591a-4391-9598-ae2dff94ecc0",
      "filename": "architecture_overview.txt",
      "page_number": 1,
      "chunk_index": 0,
      "text_snippet": "Project Antigravity is a multimodal AI companion system...",
      "score": 0.62
    }
  ],
  "has_sufficient_context": true
}
```

### 4. Crisis Intervention Interception
`POST http://127.0.0.1:8000/api/v1/chat`

**Request:**
```json
{
  "message": "I want to kill myself, I cannot handle this pain anymore"
}
```

**Response (200 OK):**
```json
{
  "conversation_id": "761611c0-0f2b-426b-b27e-851532840049",
  "message_id": "4892c23f-e14b-4f76-9214-52e4f0d2c3df",
  "response": "I hear how much pain you're carrying right now, and I care very deeply about your safety. Please know that you do not have to walk through this alone, and there is immediate, compassionate support available for you.\n\n**Immediate Support Resources (Free & Confidential, 24/7):**\n- **National Suicide and Crisis Lifeline**: Call or text **988** (available in the US and Canada).\n- **Crisis Text Line**: Text **HOME** to **741741** to connect with a crisis counselor.\n- **International Resources**: If you are outside the US/Canada, please visit **https://findahelpline.com** or call your local emergency services (such as 112 or 911).\n\nCan you reach out to someone you trust right now—a friend, family member, or professional who can be with you? Please take things one breath at a time and connect with someone who can support you right now.",
  "role": "assistant",
  "modality": "crisis_support",
  "citations": [],
  "metadata": {
    "safety_alert": "crisis_protocol_triggered"
  }
}
```

---

## 8. Security & Privacy Notes

1. **Authentication Scope**: This MVP is designed for local development and trusted standalone usage. Do not expose this instance on a public network without adding an authentication reverse-proxy (e.g. OAuth2/JWT or TLS termination).
2. **Untrusted Data Boundary**: All document chunks and image transcripts are treated as untrusted user data and enclosed in delimited XML tags with explicit directives forbidding instructions inside documents from taking control of the assistant.
3. **Sensitive Data Redaction**: The logger strips API keys, connection strings with passwords, bearer tokens, and emails automatically.
4. **Content Safety**: The emotional support module has hardcoded deterministic rules intercepting crisis keywords before invoking any LLM, ensuring that suicidal ideation triggers verified helpline resources (988).

---

## 9. Project Directory Tree

```
chatbot/
├── app.py                          # Unified launcher and diagnostic CLI utility
├── requirements.txt                # Pinned dependencies
├── .env.example                    # Environment template
├── .env                            # Local environment configuration
├── .gitignore                      # Safe ignore list
├── README.md                       # Documentation and usage guide
├── alembic.ini                     # Alembic configuration
├── alembic/
│   ├── env.py                      # SQLAlchemy metadata binding
│   ├── script.py.mako              # Migration script template
│   └── versions/
│       └── 001_initial_schema.py   # Initial database migration
├── backend/
│   ├── main.py                     # FastAPI app with CORS and exception handling
│   ├── api/
│   │   ├── deps.py                 # Dependency injection
│   │   └── routes/
│   │       ├── health.py           # Health check endpoint
│   │       ├── chat.py             # Chat endpoint
│   │       ├── conversations.py    # Conversation CRUD
│   │       ├── documents.py        # Document ingestion and deletion
│   │       ├── rag.py              # RAG query endpoint
│   │       └── audio.py            # Audio synthesis and transcription
│   ├── core/
│   │   ├── config.py               # Pydantic Settings
│   │   ├── logging_config.py       # Sensitive data redaction logger
│   │   └── security.py             # Hashing, path sanitization, magic bytes
│   ├── db/
│   │   ├── base.py                 # Declarative Base
│   │   ├── session.py              # Engine factory with fallback
│   │   └── models.py               # SQLAlchemy ORM models
│   ├── schemas/                    # Pydantic validation schemas
│   ├── services/
│   │   ├── chat_service.py         # Multi-turn context and routing
│   │   ├── rag_service.py          # Grounded retrieval and citations
│   │   ├── document_service.py     # Ingestion, deduplication, chunking
│   │   ├── emotional_support_service.py # Empathy prompts and crisis rules
│   │   ├── multimodal_service.py   # Vision extraction and audio dispatch
│   │   └── vector_store.py         # Persistent vector store abstraction
│   ├── providers/                  # LLM, Embedding, Vision, and Audio providers
│   ├── guardrails/                 # Centralized input, injection, safety, and output filters
│   └── repositories/               # Database CRUD repositories
├── frontend/
│   ├── streamlit_app.py            # Streamlit user interface
│   ├── api_client.py               # HTTPX backend client
│   └── components/
│       ├── sidebar.py              # Conversations drawer and settings
│       ├── chat_box.py             # Message bubbles and citations
│       └── document_manager.py     # Document upload and management
├── storage/
│   ├── companion.db                # SQLite fallback database
│   ├── documents/                  # Staged document uploads
│   ├── vector_store/               # Local vector index
│   └── audio_cache/                # Cached spoken audio files
└── tests/                          # 7 Pytest test suites (19 automated tests)
```
